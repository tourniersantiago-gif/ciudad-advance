import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// base relativa: el build en /dist se puede publicar en cualquier subcarpeta
export default defineConfig({
  base: './',
  plugins: [react()],
})
