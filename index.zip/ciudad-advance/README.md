# Ciudad Advance · MVP Frigorífico

Experiencia web interactiva que construye visualmente el modelo operativo de una planta frigorífica:
**procesos seleccionados → planta configurada → recorrido → módulos Advance → hardware Headway ubicado por sector.**

## Ejecutar

```bash
npm install
npm run dev        # desarrollo  → http://localhost:5173
npm run build      # producción  → /dist (estático, publicable en cualquier hosting)
npm run preview    # sirve /dist
```

Requiere Node 18+. Sin backend ni assets externos (la escena se genera desde datos).

## Stack y decisión técnica

- **React 19 + TypeScript + Vite**, estado con **Zustand**.
- **Escena 2.5D isométrica en Canvas 2D** propio (sin Three.js).
  - La estética maqueta/tycoon es isométrica fija: no requiere rotar cámara ni modelos 3D, iluminación o pipeline GLB.
  - Toda la geometría es procedural (cajas isométricas, personas, rieles, cintas): sumar sectores o industrias = sumar datos.
  - Un único loop `requestAnimationFrame`, ordenamiento por profundidad (painter's algorithm), objetos largos (rieles/cintas) divididos en tramos para ordenar bien, hit-testing en pantalla.
  - En la propuesta inicial se mencionó PixiJS: se optó por Canvas 2D nativo porque, con la cantidad de objetos del MVP, rinde a 60 fps sin dependencias extra. El renderer está aislado en `src/scene/` y puede migrarse a PixiJS/WebGL sin tocar datos ni motor.

## Arquitectura

```
src/
  data/
    types.ts                  Modelo genérico (Industry, AdvanceModule, Sector, Hardware, Preset, Matrix…)
    frigorifico/
      modules.ts              25 módulos (Advance Frigorífico, Back Office, módulos ERP, IA) con funciones y fuente
      sectors.ts              Sectores físicos: tamaño, recorrido interno, props visuales, anclajes de hardware, operarios
      hardware.ts             Productos Headway, matriz PRODUCTO × SECTOR (P / PO / O / –), tareas por sector
      index.ts                Presets de cliente + ensamblado de la industria
  engine/
    plant.ts                  Motor puro: reglas → sectores → recorrido → layout → ubicación de hardware
  scene/
    iso.ts                    Proyección y primitivas isométricas
    draw.ts                   Dibujo de props, personas, ítems de flujo, camiones, hardware
    renderer.ts               Cámara (easing, zoom, pan, foco), animación de construcción, capas, hotspots
  ui/                         Onboarding, panel “Configurá tu planta”, timeline, fichas, resumen, matriz
  store.ts                    Estado de la aplicación
```

Ninguna regla de negocio vive en componentes: `buildPlant(industry, módulosActivos, mostrarOpcionales)` devuelve el `PlantModel` completo (avisos, sectores ubicados, pasos del recorrido, trayectorias, hardware posicionado, soluciones activas).

## Reglas del configurador (engine/plant.ts)

1. **Inicio dinámico:** con Faena se agrega Hacienda; sin Faena se agrega Recepción con el ítem correspondiente al primer proceso.
2. **Encadenado** en orden canónico; cada conexión se valida contra las salidas compatibles del módulo (las no estándar se marcan en naranja y generan aviso).
3. **Cuarteo / Desposte / Empaque secundario** no son obligatorios. Faena + Desposte sin Cuarteo genera sugerencia (no se agrega automáticamente).
4. **Abasto** es una rama paralela conectada a Faena/Cuarteo/Desposte y a Expedición.
5. **Exportación** no crea sala: modifica sectores (etiquetas, calibrado, contramarcas) y agrega staging en Expedición.
6. **WMS** es capa sobre Depósito (racks extra, picking, guante lector); si falta Depósito se agrega.
7. Módulos que **requieren Back Office** muestran el edificio de Administración.
8. **Gestión** (Ventas, Compras, Finanzas, Contabilidad, CRM, RRHH, Proyectos) va en Administración, fuera del flujo.
9. **Canales digitales** generan pedidos animados hacia Depósito / Expedición.
10. **POS** crea la carnicería al final de la distribución o como local independiente.
11. **Hardware contextual:** sólo P/PO por defecto; O al activar “Mostrar también hardware opcional”. Cada familia se ubica en su anclaje (puesto fijo, punto de pesaje, riel, lectura, operario, escritorio, mostrador).
12. **Layout** en serpentina compacta (máx. 5 sectores por fila), ramas detrás y satélites al frente; se recalcula en vivo con transición.

## Agregar una industria

1. Crear `src/data/<industria>/` con `modules`, `sectors`, `hardware/matrix`, `presets` siguiendo `types.ts`.
2. Si hace falta un objeto visual nuevo, agregar un `case` en `drawProp` (`scene/draw.ts`).
3. Pasar la nueva `Industry` a `buildPlant` y al renderer.

## Información pendiente de validar

- Fichas técnicas e imágenes oficiales de MPCIA1, POS 02/03, Smart POS01, CDAR5, CDAR6, CDATQS, LCBIMJ/2/3, LCBGP, AC01, R600/R300 y balanzas (en la app figuran como “ficha pendiente”; las ilustraciones son esquemáticas).
- La matriz de hardware es la propuesta de la especificación interna; validar contra IP/ambiente y layout real.
- Colores de marca aproximados (magenta → rojo → naranja); reemplazar por el brandbook en `src/index.css` (`:root`) y `src/scene/draw.ts` (`C`).
- Nombre de la “Capa IA” (Advance IA / Creative).
- Cantidad de operarios por sector es ilustrativa.
