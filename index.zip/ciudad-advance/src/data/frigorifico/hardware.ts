import type { Hardware, MatrixRow, HwStatus, AnchorType, HardwareFamily } from '../types';

const DOC = 'Especificación Ciudad Advance (línea Headway trabajada previamente). Ficha técnica pendiente.';

export const hardware: Hardware[] = [
  {
    id: 'TI_AI02', code: 'TI AI-02', name: 'Headway TI AI-02', family: 'terminal', familyLabel: 'Terminal industrial · acero inoxidable',
    description: 'Terminal táctil industrial hermética en acero inoxidable, pensada para ambientes húmedos y de lavado en la industria frigorífica y alimenticia.',
    features: ['Chasis de acero inoxidable', 'Protección IP66 contra polvo y agua', 'Pantalla táctil resistiva Full HD: responde con guantes, grasa o humedad', 'Intel® Core™ i5 · 8 GB RAM · SSD M.2 256 GB', 'Batería integrada ante cortes de energía', 'Lavable con hidrolavadora y productos químicos'],
    verified: true, sourceNote: 'Publicaciones de Ubiar / Headway Tech (LinkedIn 2026) y nota Valor Carne (Tecno Fidta 2024).',
  },
  {
    id: 'TI_AP02', code: 'TI AP-02', name: 'Headway TI AP-02', family: 'terminal', familyLabel: 'Terminal industrial · acero pintado',
    description: 'Terminal táctil industrial con gabinete de acero pintado, para puestos industriales más controlados.',
    features: ['Gabinete de acero pintado, hermético', 'Pantalla táctil resistiva Full HD', 'Intel® Core™ i5 · almacenamiento NVMe', 'Uso continuo en línea de producción'],
    verified: true, sourceNote: 'Publicaciones de Ubiar / Headway Tech y nota Valor Carne. Ficha completa pendiente.',
  },
  {
    id: 'MPCIA1', code: 'MPCIA1', name: 'Mini PC MPCIA1', family: 'minipc', familyLabel: 'Mini PC',
    description: 'Mini PC para puestos administrativos o soluciones con monitor y periféricos separados.',
    features: ['Puesto administrativo', 'Monitor / periféricos separados', 'Evitar exposición directa en ambiente sanitario'],
    verified: false, sourceNote: DOC,
  },
  {
    id: 'POS02', code: 'POS 02', name: 'POS 02', family: 'pos', familyLabel: 'Terminal punto de venta',
    description: 'Terminal POS para caja o mostrador.', features: ['Caja / mostrador', 'Operación con Advance Punto de Venta'],
    verified: false, sourceNote: DOC,
  },
  {
    id: 'POS03', code: 'POS 03', name: 'POS 03 · doble pantalla', family: 'pos', familyLabel: 'Terminal punto de venta',
    description: 'Terminal POS con pantalla al cliente.', features: ['Doble pantalla: operador + cliente', 'Caja / mostrador'],
    verified: false, sourceNote: DOC,
  },
  {
    id: 'SMARTPOS01', code: 'Smart POS01', name: 'Smart POS01', family: 'smartpos', familyLabel: 'POS móvil',
    description: 'POS para movilidad (cobro en mostrador o en entrega).', features: ['Movilidad', 'Cobro fuera de la caja fija'],
    verified: false, sourceNote: DOC,
  },
  {
    id: 'CDAR5', code: 'CDAR5', name: 'Colector CDAR5', family: 'collector', familyLabel: 'Colector de datos',
    description: 'Colector de datos móvil para captura en recepción, inventario, picking y expedición.', features: ['En mano del operario', 'Recepción, inventario, picking, reposición, expedición'],
    verified: false, sourceNote: DOC,
  },
  {
    id: 'CDAR6', code: 'CDAR6', name: 'Colector CDAR6', family: 'collector', familyLabel: 'Colector de datos',
    description: 'Colector de datos móvil para captura en depósito, armado de paquetes, staging y carga.', features: ['En mano del operario', 'Depósito, staging y expedición'],
    verified: false, sourceNote: DOC,
  },
  {
    id: 'CDATQS', code: 'CDATQS', name: 'Tablet industrial CDATQS', family: 'tablet', familyLabel: 'Tablet industrial',
    description: 'Tablet para supervisión, calidad, mantenimiento y tareas móviles que requieren más pantalla que un colector.', features: ['Supervisión y recorridos', 'Mantenimiento y checklists'],
    verified: false, sourceNote: DOC,
  },
  {
    id: 'LCBIMJ', code: 'LCBIMJ', name: 'Lectora LCBIMJ', family: 'scanner', familyLabel: 'Lectora de códigos',
    description: 'Lectora manual de códigos para puntos de lectura repetitivos.', features: ['Lectura de etiqueta de pieza / caja', 'Mostrador o puesto fijo'],
    verified: false, sourceNote: DOC,
  },
  {
    id: 'LCBIMJ2', code: 'LCBIMJ2', name: 'Lectora LCBIMJ2', family: 'scanner', familyLabel: 'Lectora de códigos',
    description: 'Lectora manual para alta/baja y control de productos.', features: ['Alta / baja de productos', 'Control de pallets'],
    verified: false, sourceNote: DOC,
  },
  {
    id: 'LCBIMJ3', code: 'LCBIMJ3', name: 'Lectora LCBIMJ3', family: 'scanner', familyLabel: 'Lectora de códigos',
    description: 'Lectora para puestos de línea con lectura intensiva.', features: ['Lectura en línea de empaque', 'Consumo / alta de materiales'],
    verified: false, sourceNote: DOC,
  },
  {
    id: 'LCBGP', code: 'LCBGP', name: 'Guante lector LCBGP', family: 'glove', familyLabel: 'Guante lector',
    description: 'Lector tipo guante para picking/packing intensivo con manos libres.', features: ['Manos libres', 'Picking y packing intensivo'],
    verified: false, sourceNote: DOC,
  },
  {
    id: 'BALANZA', code: 'Balanza', name: 'Balanza / plataforma', family: 'scale', familyLabel: 'Balanza',
    description: 'Balanza de plataforma, mesa o control de peso integrada al punto donde el peso define la operación.', features: ['Pesaje integrado a Advance', 'Modelo según punto de pesaje'],
    verified: false, sourceNote: DOC + ' Modelos de balanza no especificados.',
  },
  {
    id: 'RIELERA', code: 'R600 / R300', name: 'Rielera R600 / R300', family: 'rail_scale', familyLabel: 'Balanza de riel',
    description: 'Balanza aérea integrada a la rielera para pesaje de reses, medias reses y cuartos.', features: ['Pesaje en riel', 'Display visible al operario'],
    verified: false, sourceNote: DOC,
  },
  {
    id: 'AC01', code: 'AC01', name: 'Autocobro AC01', family: 'selfcheckout', familyLabel: 'Isla de autocobro',
    description: 'Isla de autocobro para retail.', features: ['Zona despejada cerca de la salida'],
    verified: false, sourceNote: DOC,
  },
];

export const hardwareById = (id: string) => hardware.find((h) => h.id === id)!;

/** Columnas de la matriz → sectores físicos */
export const matrixColumns = [
  { id: 'recepcion', label: 'Recepción', sectors: ['hacienda', 'recepcion'] },
  { id: 'faena', label: 'Faena', sectors: ['faena'] },
  { id: 'cuarteo', label: 'Cuarteo', sectors: ['cuarteo'] },
  { id: 'desposte', label: 'Desposte', sectors: ['desposte'] },
  { id: 'empaque', label: 'Empaque', sectors: ['empaque1', 'empaque2'] },
  { id: 'produccion', label: 'Producción', sectors: ['produccion'] },
  { id: 'deposito', label: 'Depósito / WMS', sectors: ['deposito'] },
  { id: 'expedicion', label: 'Expedición', sectors: ['expedicion'] },
  { id: 'abasto', label: 'Abasto', sectors: ['abasto'] },
  { id: 'admin', label: 'Admin', sectors: ['admin', 'taller'] },
  { id: 'retail', label: 'Retail', sectors: ['retail'] },
];

// Fuente: tabla "Matriz de hardware por sector" + fichas de módulo (Recepción y Abasto).
// Orden de columnas: recepcion, faena, cuarteo, desposte, empaque, produccion, deposito, expedicion, abasto, admin, retail
const row = (id: string, v: string): MatrixRow => {
  const vals = v.split(' ') as (HwStatus | '-')[];
  const status: Record<string, HwStatus> = {};
  matrixColumns.forEach((c, i) => { status[c.id] = (vals[i] === '-' ? 'NA' : vals[i]) as HwStatus; });
  return { hardwareId: id, status };
};

export const matrix: MatrixRow[] = [
  //            rec fae cua des emp pro dep exp aba adm ret
  row('TI_AI02', '- P P P P O O O O - -'),
  row('TI_AP02', '- O O O P P O P O - -'),
  row('MPCIA1', '- - - - - O O O - P O'),
  row('POS02', '- - - - - - - - - - P'),
  row('POS03', '- - - - - - - - - - P'),
  row('SMARTPOS01', '- - - - - - - O - - PO'),
  row('CDAR5', 'O O O O O O P P P - O'),
  row('CDAR6', 'O O O O O O P P P - O'),
  row('CDATQS', '- O O O O PO O O - O O'),
  row('LCBIMJ2', '- O O O O O PO PO PO - O'),
  row('LCBIMJ3', '- O O PO P P PO PO PO - O'),
  row('LCBIMJ', '- O O O PO O O O - - PO'),
  row('LCBGP', '- - - - O O P O - - -'),
  row('BALANZA', 'O PO P PO P O O PO O - PO'),
  row('RIELERA', '- PO P O - - - - - - -'),
  row('AC01', '- - - - - - - - - - O'),
];

export const familyAnchor: Record<HardwareFamily, AnchorType> = {
  terminal: 'station', minipc: 'desk', pos: 'counter', smartpos: 'counter', collector: 'operator',
  tablet: 'operator', scanner: 'scan', glove: 'operator', scale: 'scale', rail_scale: 'railscale', selfcheckout: 'selfcheckout',
};

/** Tarea concreta por familia y sector (con fallback "*") */
export const tasks: Record<string, Record<string, string>> = {
  terminal: {
    faena: 'Puesto de tipificación / clasificación: registra tropa, decomisos y pesaje de cada media res. Opera offline.',
    cuarteo: 'Baja de medias reses y alta de cuartos con etiqueta por cuarto, en múltiples terminales.',
    desposte: 'Punto de alta/baja de productos: baja de cuartos al ingreso y alta de cortes con preimpresión de etiquetas.',
    empaque1: 'Terminal de empaque primario en línea: pesaje y etiquetado de cada envase.',
    empaque2: 'Terminal de encajado y etiquetado final con control de peso automático.',
    produccion: 'Declaración de producción, pesaje y etiquetado por lote (terminal offline).',
    deposito: 'Puesto de control / recepción de cámara.',
    expedicion: 'Puesto de despacho: órdenes de carga, remitos y control final.',
    abasto: 'Puesto de control de abasto: romaneos y órdenes de entrega.',
    recepcion: 'Puesto de control de recepción.',
    '*': 'Registro de la operación en el puesto fijo.',
  },
  scale: {
    hacienda: 'Pesaje de hacienda / camión en el ingreso.',
    faena: 'Pesaje de subproductos y decomisos.',
    cuarteo: 'Repesaje de cuartos.',
    desposte: 'Pesaje de cortes al darlos de alta.',
    empaque1: 'Pesaje en línea de cada envase.',
    empaque2: 'Control de peso automático de la caja cerrada.',
    expedicion: 'Pesaje de carga / ticket de balanza.',
    abasto: 'Repesajes de entregas.',
    retail: 'Venta por peso en mostrador; emisión de etiquetas y tickets de balanza.',
    '*': 'Pesaje integrado a Advance en el punto donde el peso define la operación.',
  },
  rail_scale: {
    faena: 'Pesaje de cada media res en la rielera.',
    cuarteo: 'Pesaje en riel de medias reses y cuartos.',
    desposte: 'Pesaje en riel al ingreso a desposte.',
    '*': 'Pesaje aéreo en la rielera.',
  },
  scanner: {
    desposte: 'Lectura de etiqueta de cuarto en la baja y del corte en el alta.',
    empaque1: 'Lectura de la etiqueta primaria en línea.',
    empaque2: 'Lectura de caja antes / después del cierre.',
    produccion: 'Consumo y alta de materiales por código.',
    deposito: 'Lectura de pallets en el control de cámara.',
    expedicion: 'Control de pallets y cajas en la carga.',
    retail: 'Lectura de productos por código en caja.',
    '*': 'Lectura de etiqueta de pieza, caja o pallet.',
  },
  collector: {
    hacienda: 'Recepción móvil de hacienda / documentación.',
    recepcion: 'Recepción de mercadería en el muelle.',
    deposito: 'Ubicación, inventario, picking y reposición en cámara.',
    expedicion: 'Control de carga por pallet y caja en el muelle.',
    abasto: 'Armado de paquetes y control de entregas.',
    '*': 'Captura móvil en mano del operario.',
  },
  glove: { '*': 'Picking / packing intensivo con manos libres.' },
  tablet: { taller: 'El técnico recorre equipos: checklists, lecturas y órdenes de trabajo.', '*': 'Supervisión y calidad en recorrida.' },
  minipc: { admin: 'Puesto administrativo con monitor: Back Office y tableros.', '*': 'Puesto de control con monitor separado.' },
  pos: { retail: 'Caja / mostrador: facturación, medios de pago y cierres de caja.', '*': 'Caja.' },
  smartpos: { '*': 'Cobro móvil.' },
  selfcheckout: { '*': 'Autocobro del cliente cerca de la salida.' },
};
