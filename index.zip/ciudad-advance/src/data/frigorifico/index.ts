import type { Industry, Preset, HwStatus } from '../types';
import { modules } from './modules';
import { sectors } from './sectors';
import { hardware, matrix, matrixColumns, tasks } from './hardware';

const INTEGRAL = ['faena', 'cuarteo', 'desposte', 'empaque_primario', 'empaque_secundario', 'deposito', 'logistica'];

export const presets: Preset[] = [
  { id: 'faenador', name: 'Faenador', short: 'Faena con salida a cámara y despacho', modules: ['faena', 'abasto', 'deposito', 'logistica'], frequentOptional: ['cuarteo', 'exportacion', 'wms'], baseRoute: 'Hacienda › Faena › Depósito › Expedición' },
  { id: 'faena_cuarteo', name: 'Faena + Cuarteo', short: 'Faena y cuarteo con salida a cámara', modules: ['faena', 'cuarteo', 'deposito', 'logistica'], frequentOptional: ['abasto', 'desposte', 'exportacion'], baseRoute: 'Hacienda › Faena › Cuarteo › Depósito' },
  { id: 'despostador', name: 'Despostador', short: 'Ingreso de medias reses / cuartos y desposte', modules: ['desposte', 'deposito', 'logistica'], frequentOptional: ['empaque_primario', 'empaque_secundario', 'abasto', 'exportacion'], baseRoute: 'Recepción › Desposte › Depósito › Expedición' },
  { id: 'desposte_empaque', name: 'Desposte + Empaque', short: 'Desposte con línea de empaque', modules: ['desposte', 'empaque_primario', 'empaque_secundario', 'deposito'], frequentOptional: ['wms', 'exportacion'], baseRoute: 'Recepción › Desposte › Empaque 1 › Empaque 2 › Depósito' },
  { id: 'integral', name: 'Frigorífico integral', short: 'Ciclo completo: de la hacienda a la expedición', modules: INTEGRAL, frequentOptional: ['abasto', 'wms', 'exportacion', 'pos'], baseRoute: 'Hacienda › Faena › Cuarteo › Desposte › Empaque › Depósito › Expedición' },
  { id: 'exportador', name: 'Frigorífico exportador', short: 'Integral + exportación + WMS', modules: [...INTEGRAL, 'exportacion', 'wms'], frequentOptional: ['abasto'], baseRoute: 'Proceso › Empaque › WMS / staging › Exportación' },
  { id: 'elaborador', name: 'Frigorífico elaborador', short: 'Producción, empaque y depósito', modules: ['produccion', 'empaque_primario', 'empaque_secundario', 'deposito', 'logistica'], frequentOptional: ['desposte', 'wms'], baseRoute: 'Materia prima › Producción › Empaque › Depósito' },
  { id: 'planta_retail', name: 'Frigorífico + Retail', short: 'Planta integral con carnicerías propias', modules: [...INTEGRAL, 'pos', 'ventas'], frequentOptional: ['ecommerce', 'wms', 'crm'], baseRoute: 'Planta › Depósito › Distribución › Carnicerías / POS' },
  { id: 'abasto_distribuidor', name: 'Distribuidor / Abasto', short: 'Recepción, depósito, preparación y despacho', modules: ['abasto', 'deposito', 'logistica', 'ventas'], frequentOptional: ['wms', 'b2b', 'pos'], baseRoute: 'Recepción › Depósito › Preparación › Despacho' },
  { id: 'retail_sin_planta', name: 'Cadena retail sin planta', short: 'Depósito central y carnicerías', modules: ['ventas', 'deposito', 'pos'], frequentOptional: ['ecommerce', 'b2b', 'crm', 'wms'], baseRoute: 'Recepción › Depósito › Reposición › POS' },
  { id: 'centro_logistico', name: 'Centro logístico', short: 'Depósito con WMS y expedición', modules: ['deposito', 'wms', 'logistica'], frequentOptional: ['abasto', 'b2b', 'ecommerce'], baseRoute: 'Recepción › Ubicación › Picking › Expedición' },
  { id: 'personalizado', name: 'Personalizado', short: 'Empezá desde cero y elegí cada proceso', modules: [], frequentOptional: [], baseRoute: '—' },
];

/** Overrides de matriz por sector (cuando la ficha del módulo es más específica que la columna general) */
export const sectorOverrides: Record<string, Record<string, HwStatus>> = {
  taller: { CDATQS: 'P', CDAR6: 'O', MPCIA1: 'O' },
};

export const frigorifico: Industry = {
  id: 'frigorifico',
  name: 'Frigorífico',
  modules,
  sectors,
  hardware,
  matrixColumns,
  matrix,
  tasks,
  presets,
  receptionItems: {
    cuarteo: 'Medias reses',
    desposte: 'Medias reses / cuartos',
    produccion: 'Materias primas / cortes',
    empaque1: 'Cortes',
    empaque2: 'Producto envasado',
    deposito: 'Mercadería',
    expedicion: 'Mercadería',
  },
};
