// ─────────────────────────────────────────────────────────────
// Ciudad Advance · modelo de datos genérico (reutilizable por industria)
// Ninguna regla de negocio vive en los componentes: todo sale de aquí.
// ─────────────────────────────────────────────────────────────

/** P = principal · O = opcional · PO = principal u opcional según operación · NA = no aplica */
export type HwStatus = 'P' | 'O' | 'PO' | 'NA';

export type ModuleCategory =
  | 'physical_process'   // sala / etapa productiva
  | 'physical_operation' // sala / cámara / depósito
  | 'logistics_node'     // nodo de expedición o rama logística
  | 'rule_layer'         // regla que modifica otros sectores (Exportación)
  | 'advanced_layer'     // capa avanzada sobre un sector (WMS)
  | 'management'         // oficina / capa de gestión
  | 'digital_channel'    // canal digital sin sala física
  | 'retail_channel'     // local / caja
  | 'support'            // soporte (Mantenimiento)
  | 'transversal';       // BI, Assistant, capa IA

export type ModuleGroup = 'procesos' | 'logistica' | 'comercial' | 'gestion' | 'transversal';

export interface AdvanceModule {
  id: string;
  name: string;
  /** Producto / suite comercial a la que pertenece */
  suite: string;
  /** Nombre del módulo Advance tal como figura en la documentación (puede diferir del nombre visible) */
  advanceModuleName: string;
  group: ModuleGroup;
  category: ModuleCategory;
  representation: 'room' | 'line' | 'node' | 'layer' | 'office' | 'portal' | 'store';
  selectable: boolean;
  canStartFlow: boolean;
  /** dependencias de licencia/documentación (p.ej. requiere Back Office) */
  requires?: string[];
  /** sectores físicos que crea */
  sectors: string[];
  /** sectores físicos que modifica sin crear sala */
  modifies?: Record<string, string[]>;
  inputs: string[];
  outputs: string[];
  shortDescription: string;
  aiContext: string;
  /** funciones textuales de brochure / ubiar.com */
  functions: string[];
  source: string;
}

export type HardwareFamily =
  | 'terminal' | 'minipc' | 'pos' | 'smartpos' | 'collector' | 'tablet'
  | 'scanner' | 'glove' | 'scale' | 'rail_scale' | 'selfcheckout';

export type AnchorType = 'station' | 'scale' | 'railscale' | 'scan' | 'operator' | 'desk' | 'counter' | 'selfcheckout';

export interface Hardware {
  id: string;
  code: string;
  name: string;
  family: HardwareFamily;
  familyLabel: string;
  description: string;
  features: string[];
  /** true = datos confirmados con fuente pública; false = sólo documento interno / pendiente */
  verified: boolean;
  sourceNote: string;
}

export interface SectorProp {
  type: string;
  x: number; y: number;
  w?: number; d?: number; h?: number;
  /** variante libre */
  v?: string;
  /** sólo se dibuja si el módulo/flag indicado está activo */
  when?: string;
}

export interface Sector {
  id: string;
  name: string;
  kind: 'yard' | 'process' | 'storage' | 'dock' | 'office' | 'store' | 'portal' | 'workshop';
  lane: 'main' | 'branch' | 'satellite';
  /** orden canónico en la línea principal */
  order: number;
  size: { w: number; d: number };
  wallHeight: number;
  walls: boolean;
  cold?: boolean;
  /** módulo Advance que lo gestiona (para chips/fichas) */
  advanceLabel: string;
  process: string;
  operatorsLabel: string;
  inputsLabel: string[];
  outputsLabel: string[];
  /** ítem de flujo que sale del sector (para animación y trazabilidad) */
  outItem: FlowItem;
  /** altura del flujo de producto dentro del sector (riel = 2, mesa/cinta = 0.75, piso = 0) */
  flowZ: number;
  /** recorrido interno local (entrada → salida) */
  flowPath: [number, number][];
  traceLabel: string;
  props: SectorProp[];
  anchors: Partial<Record<AnchorType, [number, number][]>>;
  operators: { x: number; y: number; role: 'plant' | 'logistic' | 'office' | 'retail' | 'tech'; walk?: [number, number][] }[];
}

export type FlowItem = 'animal' | 'media_res' | 'cuarto' | 'corte' | 'envase' | 'caja' | 'pallet' | 'producto' | 'pedido' | 'none';

export interface Preset {
  id: string;
  name: string;
  short: string;
  modules: string[];
  frequentOptional: string[];
  baseRoute: string;
}

export interface MatrixRow { hardwareId: string; status: Record<string, HwStatus> }

export interface Industry {
  id: string;
  name: string;
  modules: AdvanceModule[];
  sectors: Sector[];
  hardware: Hardware[];
  /** columnas de matriz → sectores físicos */
  matrixColumns: { id: string; label: string; sectors: string[] }[];
  matrix: MatrixRow[];
  /** tarea concreta de cada familia en cada sector (fallback por familia) */
  tasks: Record<string, Record<string, string>>;
  presets: Preset[];
  /** Ítem de entrada según el sector en el que empieza el recorrido (cuando no hay Faena) */
  receptionItems: Record<string, string>;
}
