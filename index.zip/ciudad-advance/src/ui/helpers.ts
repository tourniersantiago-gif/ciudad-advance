import { frigorifico } from '../data/frigorifico';
import type { AdvanceModule } from '../data/types';
import type { PlantModel } from '../engine/plant';

export const IND = frigorifico;

const SECTOR_MODULE: Record<string, string> = { hacienda: 'faena', recepcion: 'deposito', expedicion: 'logistica', admin: 'ventas', taller: 'mantenimiento', digital: 'ecommerce', retail: 'pos' };

export function modulesForSector(model: PlantModel, sectorId: string): AdvanceModule[] {
  const ps = model.sectors.find((s) => s.id === sectorId);
  const ids = new Set(ps?.modules ?? []);
  if (!ids.size && SECTOR_MODULE[sectorId] && model.active.includes(SECTOR_MODULE[sectorId])) ids.add(SECTOR_MODULE[sectorId]);
  if (sectorId === 'hacienda' && model.active.includes('faena')) ids.add('faena');
  return IND.modules.filter((m) => ids.has(m.id));
}

export function primaryModule(sectorId: string): AdvanceModule | undefined {
  const id = SECTOR_MODULE[sectorId] ?? IND.modules.find((m) => m.sectors.includes(sectorId))?.id;
  return IND.modules.find((m) => m.id === id);
}

export const STATUS_LABEL: Record<string, string> = { P: 'Principal', PO: 'Principal / opcional', O: 'Opcional', NA: 'No aplica' };

export const ANCHOR_LABEL: Record<string, string> = {
  station: 'Puesto fijo junto a la decisión / registro de la operación, sin invadir riel ni cinta.',
  scale: 'Integrada al punto donde el peso define la operación.',
  railscale: 'Sobre la rielera, con display visible al operario.',
  scan: 'En el punto de lectura repetitivo (pieza, caja o pallet).',
  operator: 'En mano del operario / técnico que se desplaza.',
  desk: 'Puesto administrativo con monitor separado, fuera del ambiente sanitario.',
  counter: 'Caja / mostrador comercial.',
  selfcheckout: 'Zona despejada y accesible cerca de la salida.',
};

export const CATEGORY_LABEL: Record<string, string> = {
  physical_process: 'Sala', physical_operation: 'Sala', logistics_node: 'Nodo', rule_layer: 'Regla',
  advanced_layer: 'Capa', management: 'Oficina', digital_channel: 'Canal', retail_channel: 'Local', support: 'Soporte', transversal: 'Capa',
};
