import { useStore, sceneApi } from '../store';
import type { PlantModel } from '../engine/plant';
import { IND, modulesForSector, primaryModule, STATUS_LABEL, ANCHOR_LABEL } from './helpers';
import { HardwareIcon } from './HardwareIcon';

export function SectorSheet({ model }: { model: PlantModel }) {
  const { selectedSector, selectSector, selectHw } = useStore();
  const ps = model.sectors.find((s) => s.id === selectedSector);
  if (!ps) return null;
  const sec = ps.sector;
  const mods = modulesForSector(model, sec.id);
  const pm = primaryModule(sec.id);
  const hw = model.hardware.filter((h) => h.sectorId === sec.id && (h.status !== 'O' || h.pos || useStore.getState().showOptional));
  const optionalHidden = model.hardware.filter((h) => h.sectorId === sec.id && h.status === 'O' && !h.pos);
  const idx = model.steps.findIndex((s) => s.sectorId === sec.id);
  const prev = idx > 0 ? model.steps[idx - 1] : null;
  const next = idx >= 0 && idx < model.steps.length - 1 ? model.steps[idx + 1] : null;
  const go = (id: string) => { selectSector(id); sceneApi.r?.focusSector(id); };
  const back = () => { selectSector(null); sceneApi.r?.fitAll(true); };
  const title = sec.id === 'expedicion' && !model.flags.logistica ? 'Despacho' : sec.name;

  return (
    <aside className="sheet">
      <div className="sheet-top">
        <button className="ghost" onClick={back}>← Volver a planta</button>
        <button className="icon" onClick={back} aria-label="Cerrar">×</button>
      </div>
      <div className="sheet-scroll">
        {idx >= 0 && <div className="eyebrow">Paso {idx + 1} de {model.steps.length}</div>}
        <h2>{title}</h2>
        <p className="lead">{pm?.shortDescription ?? sec.process}</p>
        <div className="adv-chip">{sec.advanceLabel}</div>

        <h5>Qué sucede aquí</h5>
        <p>{sec.process}</p>

        <div className="io">
          <div><h5>Entradas</h5><ul>{sec.inputsLabel.map((x) => <li key={x}>{x}</li>)}</ul></div>
          <div><h5>Salidas</h5><ul>{sec.outputsLabel.map((x) => <li key={x}>{x}</li>)}</ul></div>
        </div>

        <h5>Operarios</h5>
        <p>{sec.operatorsLabel}</p>

        {mods.length > 0 && <>
          <h5>Advance en este sector</h5>
          {mods.map((m) => (
            <div key={m.id} className="mod-card">
              <div className="mod-card-title">{m.suite.split(' · ')[0]} · {m.advanceModuleName}</div>
              <ul>{m.functions.map((f) => <li key={f}>{f}</li>)}</ul>
              <div className="src">Fuente: {m.source}</div>
            </div>
          ))}
        </>}

        {ps.modifiers.length > 0 && <>
          <h5>Reglas activas sobre este sector</h5>
          <ul className="mods">{ps.modifiers.map((md, i) => <li key={i}><span className="tag">{IND.modules.find((m) => m.id === md.module)?.name}</span> {md.text}</li>)}</ul>
        </>}

        {model.flags.assistant && <p className="muted small">Advance Assistant disponible en las pantallas de este sector.</p>}

        <h5>Hardware Headway</h5>
        {hw.length === 0 && <p className="muted">Este sector no requiere hardware dedicado.</p>}
        <div className="hw-list">
          {hw.map((h) => {
            const d = IND.hardware.find((x) => x.id === h.hwId)!;
            return (
              <button key={h.key} className="hw-item" onClick={() => selectHw(h.key)}>
                <HardwareIcon family={d.family} size={40} />
                <span className="hw-txt"><b>{d.code}</b><span>{d.familyLabel}</span></span>
                <span className={`st st-${h.status}`}>{h.status}</span>
                {!h.pos && <span className="muted tiny">compatible</span>}
              </button>
            );
          })}
        </div>
        {optionalHidden.length > 0 && !useStore.getState().showOptional && <p className="muted small">+{optionalHidden.length} equipos opcionales (activá “Mostrar también hardware opcional”).</p>}

        <div className="sheet-nav">
          {prev ? <button className="ghost" onClick={() => go(prev.sectorId)}>← {prev.label}</button> : <span />}
          {next ? <button className="ghost" onClick={() => go(next.sectorId)}>{next.label} →</button> : <span />}
        </div>
      </div>
    </aside>
  );
}

export function HardwareSheet({ model }: { model: PlantModel }) {
  const { selectedHw, selectHw } = useStore();
  const h = model.hardware.find((x) => x.key === selectedHw);
  if (!h) return null;
  const d = IND.hardware.find((x) => x.id === h.hwId)!;
  const sec = IND.sectors.find((s) => s.id === h.sectorId)!;
  const row = IND.matrix.find((r) => r.hardwareId === d.id)!;
  const where = IND.matrixColumns.filter((c) => row.status[c.id] === 'P' || row.status[c.id] === 'PO').map((c) => c.label);
  return (
    <div className="modal-back" onClick={() => selectHw(null)}>
      <div className="hw-sheet" onClick={(e) => e.stopPropagation()}>
        <button className="icon close" onClick={() => selectHw(null)} aria-label="Cerrar">×</button>
        <div className="hw-hero"><HardwareIcon family={d.family} size={150} /></div>
        <div className="eyebrow">Headway · {d.familyLabel}</div>
        <h2>{d.name}</h2>
        <div className="row-badges">
          <span className={`st st-${h.status}`}>{STATUS_LABEL[h.status]}</span>
          <span className="tag">{sec.name}</span>
          {!d.verified && <span className="tag warn">ficha pendiente</span>}
        </div>
        <p>{d.description}</p>
        <h5>Función en {sec.name}</h5>
        <p>{h.task}</p>
        <h5>Ubicación</h5>
        <p>{ANCHOR_LABEL[h.anchor]}</p>
        <h5>Características</h5>
        <ul>{d.features.map((f) => <li key={f}>{f}</li>)}</ul>
        {where.length > 0 && <><h5>También principal en</h5><p className="muted">{where.join(' · ')}</p></>}
        <div className="src">{d.verified ? 'Fuente: ' : 'Estado: '}{d.sourceNote}</div>
      </div>
    </div>
  );
}
