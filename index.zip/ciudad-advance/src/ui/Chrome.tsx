import { Fragment } from 'react';
import { useStore, sceneApi } from '../store';
import type { PlantModel } from '../engine/plant';
import type { Layer } from '../scene/renderer';
import { IND } from './helpers';
import { HardwareIcon } from './HardwareIcon';

const LAYERS: { id: Layer; label: string; hint: string }[] = [
  { id: 'planta', label: 'Planta', hint: 'Vista limpia sin overlays' },
  { id: 'recorrido', label: 'Recorrido', hint: 'Flujo del producto' },
  { id: 'advance', label: 'Advance', hint: 'Dónde interviene el software' },
  { id: 'headway', label: 'Headway', hint: 'Dispositivos físicos' },
  { id: 'trazabilidad', label: 'Trazabilidad', hint: 'Identificación del producto en cada paso' },
];

export function Logo() {
  return (
    <div className="logo">
      <span className="logo-mark" />
      <span><b>Ciudad</b> Advance</span>
    </div>
  );
}

export function TopBar() {
  const { layer, setLayer, setDrawer, drawerOpen, summaryOpen, setSummary, setMatrix } = useStore();
  return (
    <header className="topbar">
      <button className="icon only-mobile" onClick={() => setDrawer(!drawerOpen)} aria-label="Configurar">☰</button>
      <Logo />
      <span className="ind-chip">Frigorífico</span>
      <nav className="layers">
        {LAYERS.map((l) => (
          <button key={l.id} className={layer === l.id ? 'on' : ''} onClick={() => setLayer(l.id)} title={l.hint}>{l.label}</button>
        ))}
      </nav>
      <div className="top-actions">
        <button className="ghost hide-mobile" onClick={() => setMatrix(true)}>Matriz hardware</button>
        <button className={`ghost ${summaryOpen ? 'on' : ''}`} onClick={() => setSummary(!summaryOpen)}>Resumen</button>
      </div>
    </header>
  );
}

export function Timeline({ model }: { model: PlantModel }) {
  const { selectedSector, selectSector } = useStore();
  const focus = (id: string) => { selectSector(id); sceneApi.r?.focusSector(id); };
  const extras = [
    model.sectors.find((s) => s.id === 'abasto') && { id: 'abasto', label: 'Abasto', sub: 'circuito paralelo' },
    model.flags.exportacion && { id: 'expedicion', label: 'Exportación', sub: 'regla + staging' },
    model.flags.wms && { id: 'deposito', label: 'WMS', sub: 'capa sobre depósito' },
    model.sectors.find((s) => s.id === 'digital') && { id: 'digital', label: 'Canales digitales', sub: 'pedidos' },
    model.sectors.find((s) => s.id === 'admin') && { id: 'admin', label: 'Administración', sub: 'Back Office' },
    model.sectors.find((s) => s.id === 'taller') && { id: 'taller', label: 'Mantenimiento', sub: 'soporte' },
    model.sectors.find((s) => s.id === 'retail') && !model.steps.some((s) => s.sectorId === 'retail') && { id: 'retail', label: 'Carnicería / POS', sub: 'local' },
  ].filter(Boolean) as { id: string; label: string; sub: string }[];
  return (
    <div className="timeline">
      <button className="tl-home" onClick={() => { selectSector(null); sceneApi.r?.fitAll(true); }} title="Volver a planta">⌂</button>
      <div className="tl-scroll">
        <span className="tl-title">Recorrido</span>
        {model.steps.length === 0 && <span className="muted small">Sin procesos físicos seleccionados</span>}
        {model.steps.map((s, i) => (
          <Fragment key={s.sectorId}>
            {i > 0 && <span className={`tl-arrow ${model.edgesWarn.includes(`${model.steps[i - 1].sectorId}>${s.sectorId}`) ? 'warn' : ''}`}>→</span>}
            <button className={`tl-step ${selectedSector === s.sectorId ? 'on' : ''}`} onClick={() => focus(s.sectorId)}>
              <span className="n">{i + 1}</span>
              <span className="tl-l"><b>{s.label}</b>{s.sub && <small>{s.sub}</small>}</span>
            </button>
          </Fragment>
        ))}
        {extras.length > 0 && <span className="tl-sep" />}
        {extras.map((e) => (
          <button key={e.label} className={`tl-step extra ${selectedSector === e.id ? 'on' : ''}`} onClick={() => focus(e.id)}>
            <span className="tl-l"><b>{e.label}</b><small>{e.sub}</small></span>
          </button>
        ))}
      </div>
    </div>
  );
}

export function Summary({ model }: { model: PlantModel }) {
  const { presetId, active, setSummary, showOptional } = useStore();
  const preset = IND.presets.find((p) => p.id === presetId);
  const modified = preset && (preset.modules.length !== active.length || preset.modules.some((m) => !active.includes(m)));
  const groups = new Map<string, Set<string>>();
  model.hardware.filter((h) => h.status !== 'O' || showOptional).forEach((h) => {
    const d = IND.hardware.find((x) => x.id === h.hwId)!;
    const key = d.familyLabel.split(' · ')[0];
    if (!groups.has(key)) groups.set(key, new Set());
    groups.get(key)!.add(d.code);
  });
  return (
    <div className="summary">
      <div className="sum-head"><span className="eyebrow">Modelo de planta</span><button className="icon" onClick={() => setSummary(false)}>×</button></div>
      <h3>{preset ? preset.name : 'Personalizado'}{modified && <small> · personalizado</small>}</h3>
      <h5>Recorrido</h5>
      <div className="sum-route">{model.steps.map((s) => s.label).join(' → ') || '—'}</div>
      <h5>Soluciones activas</h5>
      <div className="chips">{model.solutions.map((s) => <span key={s} className="chip">{s}</span>)}</div>
      <h5>Hardware</h5>
      {[...groups.entries()].map(([k, v]) => (
        <div key={k} className="sum-hw"><b>{k}</b><span>{[...v].join(' · ')}</span></div>
      ))}
      {groups.size === 0 && <div className="muted small">Sin hardware para esta configuración.</div>}
    </div>
  );
}

export function MatrixModal({ model }: { model: PlantModel }) {
  const { setMatrix } = useStore();
  const activeSectors = new Set(model.sectors.map((s) => s.id));
  return (
    <div className="modal-back" onClick={() => setMatrix(false)}>
      <div className="matrix" onClick={(e) => e.stopPropagation()}>
        <div className="sum-head"><div><div className="eyebrow">Headway × sectores</div><h3>Matriz de hardware</h3></div><button className="icon" onClick={() => setMatrix(false)}>×</button></div>
        <p className="muted small">P = principal · PO = principal u opcional según operación · O = opcional. Propuesta de la especificación; validar contra ambiente/IP y layout final. Columnas resaltadas = sectores activos.</p>
        <div className="mx-scroll">
          <table>
            <thead><tr><th>Producto</th>{IND.matrixColumns.map((c) => <th key={c.id} className={c.sectors.some((s) => activeSectors.has(s)) ? 'act' : ''}>{c.label}</th>)}</tr></thead>
            <tbody>
              {IND.matrix.map((r) => {
                const d = IND.hardware.find((h) => h.id === r.hardwareId)!;
                return (
                  <tr key={r.hardwareId}>
                    <td className="mx-name"><HardwareIcon family={d.family} size={26} /> <span><b>{d.code}</b><small>{d.familyLabel}</small></span></td>
                    {IND.matrixColumns.map((c) => {
                      const v = r.status[c.id];
                      return <td key={c.id} className={c.sectors.some((s) => activeSectors.has(s)) ? 'act' : ''}>{v === 'NA' ? <span className="na">–</span> : <span className={`st st-${v}`}>{v}</span>}</td>;
                    })}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

export function Intro() {
  const { setStage } = useStore();
  return (
    <div className="overlay intro">
      <div className="intro-card">
        <Logo />
        <h1>Ciudad Advance</h1>
        <p>Descubrí cómo Advance conecta toda tu operación.</p>
        <button className="btn-primary" onClick={() => setStage('preset')}>Configurar mi planta</button>
        <div className="muted small">Industria: Frigoríficos · Advance Frigorífico + Advance ERP + Headway Tech</div>
      </div>
    </div>
  );
}

export function PresetPicker() {
  const { applyPreset, setStage } = useStore();
  const order = ['faenador', 'faena_cuarteo', 'despostador', 'desposte_empaque', 'integral', 'exportador', 'elaborador', 'planta_retail', 'abasto_distribuidor', 'retail_sin_planta', 'centro_logistico', 'personalizado'];
  return (
    <div className="overlay presets">
      <div className="preset-wrap">
        <div className="eyebrow">Paso 1 de 2</div>
        <h2>¿Qué modelo se parece más a tu empresa?</h2>
        <p className="muted">Es sólo un punto de partida: después podés activar o desactivar cada proceso.</p>
        <div className="preset-grid">
          {order.map((id) => {
            const p = IND.presets.find((x) => x.id === id)!;
            return (
              <button key={id} className="preset-card" onClick={() => { applyPreset(id); setStage('config'); }}>
                <b>{p.name}</b>
                <span>{p.short}</span>
                <small>{p.baseRoute}</small>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}

export function RoutePreview({ model }: { model: PlantModel }) {
  return (
    <div className="preview">
      <div className="eyebrow">Paso 2 de 2 · Recorrido previsto</div>
      <div className="preview-route">
        {model.steps.length === 0 && <span className="muted">Activá al menos un proceso para construir el recorrido.</span>}
        {model.steps.map((s, i) => (
          <Fragment key={s.sectorId}>
            {i > 0 && <span className="tl-arrow">→</span>}
            <span className="pv-step"><span className="n">{i + 1}</span>{s.label}{s.sub && <small>{s.sub}</small>}</span>
          </Fragment>
        ))}
      </div>
      <div className="chips">{model.solutions.map((s) => <span key={s} className="chip">{s}</span>)}</div>
    </div>
  );
}

export function BuildToast() {
  const phase = useStore((s) => s.buildPhase);
  if (!phase) return null;
  return (
    <div className="build-toast">
      <span className="spinner" />
      <div><b>Estamos configurando tu operación</b><span>{phase}…</span></div>
    </div>
  );
}
