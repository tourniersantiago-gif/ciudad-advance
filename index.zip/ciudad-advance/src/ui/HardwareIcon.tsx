import type { HardwareFamily } from '../data/types';

/** Ilustración esquemática por familia (placeholder hasta contar con renders oficiales Headway) */
export function HardwareIcon({ family, size = 120 }: { family: HardwareFamily; size?: number }) {
  const g = (
    <defs>
      <linearGradient id="adv" x1="0" x2="1">
        <stop offset="0" stopColor="#E6007E" /><stop offset="1" stopColor="#FF7A1A" />
      </linearGradient>
      <linearGradient id="steel" x1="0" x2="1">
        <stop offset="0" stopColor="#e9edf2" /><stop offset="1" stopColor="#c3cad3" />
      </linearGradient>
    </defs>
  );
  const screen = (x: number, y: number, w: number, h: number) => (
    <g>
      <rect x={x} y={y} width={w} height={h} rx={2} fill="#fff" />
      <rect x={x} y={y} width={w} height={h * 0.16} rx={2} fill="url(#adv)" />
      {[0, 1, 2].map((i) => <rect key={i} x={x + w * 0.08} y={y + h * (0.28 + i * 0.2)} width={w * 0.84} height={h * 0.12} rx={1.5} fill={i === 1 ? '#ffd0e6' : '#eceff3'} />)}
    </g>
  );
  let body: React.ReactNode;
  switch (family) {
    case 'terminal':
      body = (<g><rect x="56" y="78" width="8" height="30" fill="#aab2bd" /><rect x="38" y="106" width="44" height="6" rx="3" fill="#9aa3b0" /><rect x="18" y="18" width="84" height="62" rx="6" fill="url(#steel)" stroke="#9aa3b0" />{screen(25, 25, 70, 48)}</g>);
      break;
    case 'minipc':
      body = (<g><rect x="20" y="22" width="80" height="50" rx="4" fill="#2c3038" />{screen(25, 27, 70, 40)}<rect x="56" y="72" width="8" height="14" fill="#9aa3b0" /><rect x="34" y="92" width="52" height="14" rx="3" fill="#2c3038" /><circle cx="78" cy="99" r="2" fill="#5dffb0" /></g>);
      break;
    case 'pos': case 'smartpos':
      body = family === 'smartpos'
        ? (<g><rect x="40" y="14" width="40" height="92" rx="8" fill="#2c3038" />{screen(45, 22, 30, 50)}<rect x="46" y="80" width="28" height="18" rx="3" fill="#3d424c" /></g>)
        : (<g><rect x="30" y="92" width="60" height="16" rx="4" fill="#2c3038" /><rect x="56" y="70" width="8" height="24" fill="#5a606b" /><rect x="22" y="18" width="76" height="56" rx="5" fill="#2c3038" />{screen(27, 23, 66, 46)}</g>);
      break;
    case 'collector':
      body = (<g><rect x="42" y="10" width="36" height="100" rx="9" fill="#2c3038" />{screen(47, 20, 26, 40)}{[0, 1, 2].map((r) => [0, 1, 2].map((c) => <rect key={`${r}${c}`} x={48 + c * 9} y={68 + r * 9} width={7} height={6} rx={1.5} fill="#5a606b" />))}<rect x="52" y="6" width="16" height="6" rx="2" fill="#E6007E" /></g>);
      break;
    case 'tablet':
      body = (<g><rect x="12" y="24" width="96" height="70" rx="10" fill="#2c3038" />{screen(20, 31, 80, 56)}<rect x="8" y="30" width="6" height="58" rx="3" fill="#ffb347" /><rect x="106" y="30" width="6" height="58" rx="3" fill="#ffb347" /></g>);
      break;
    case 'scanner':
      body = (<g><path d="M30 40 h50 a10 10 0 0 1 10 10 v8 a10 10 0 0 1 -10 10 h-22 l-8 40 h-16 l6 -40 h-10 a10 10 0 0 1 -10 -10 v-8 a10 10 0 0 1 10 -10z" fill="#2c3038" /><rect x="86" y="46" width="6" height="16" fill="#E6007E" /><path d="M92 54 L116 44 M92 54 L116 64" stroke="#ff3b4e" strokeWidth="2" /></g>);
      break;
    case 'glove':
      body = (<g><path d="M34 100 v-46 a8 8 0 0 1 16 0 v-16 a8 8 0 0 1 16 0 v8 a8 8 0 0 1 16 0 v34 l8 -10 a8 8 0 0 1 12 10 l-20 30z" fill="#3a3f48" /><rect x="40" y="62" width="36" height="22" rx="4" fill="#1f2329" /><rect x="44" y="66" width="12" height="6" fill="#E6007E" /></g>);
      break;
    case 'scale':
      body = (<g><rect x="14" y="80" width="92" height="16" rx="4" fill="url(#steel)" stroke="#9aa3b0" /><rect x="84" y="30" width="6" height="52" fill="#9aa3b0" /><rect x="66" y="18" width="42" height="22" rx="4" fill="#2c3038" /><rect x="71" y="24" width="32" height="10" fill="#5dffb0" /></g>);
      break;
    case 'rail_scale':
      body = (<g><rect x="10" y="20" width="100" height="8" rx="4" fill="#8c95a3" /><rect x="56" y="28" width="8" height="24" fill="#9aa3b0" /><rect x="36" y="50" width="48" height="26" rx="4" fill="#2c3038" /><rect x="42" y="57" width="36" height="12" fill="#5dffb0" /><path d="M60 76 v18 m-6 0 h12" stroke="#7d8592" strokeWidth="3" /></g>);
      break;
    case 'selfcheckout':
      body = (<g><rect x="34" y="50" width="52" height="60" rx="4" fill="#e9ecf1" stroke="#c3cad3" /><rect x="30" y="12" width="60" height="42" rx="4" fill="#2c3038" />{screen(35, 17, 50, 32)}<rect x="46" y="64" width="28" height="6" rx="2" fill="#2c3038" /></g>);
      break;
    default:
      body = null;
  }
  return (<svg viewBox="0 0 120 120" width={size} height={size} aria-hidden>{g}{body}</svg>);
}
