import { useStore } from '../store';
import type { PlantModel } from '../engine/plant';
import { IND, CATEGORY_LABEL } from './helpers';

const GROUPS: { id: string; title: string; ids: string[] }[] = [
  { id: 'procesos', title: 'Procesos de planta', ids: ['faena', 'cuarteo', 'desposte', 'empaque_primario', 'empaque_secundario', 'produccion'] },
  { id: 'logistica', title: 'Almacenamiento y logística', ids: ['deposito', 'wms', 'logistica', 'abasto', 'exportacion'] },
  { id: 'comercial', title: 'Canales comerciales', ids: ['pos', 'ecommerce', 'b2b'] },
  { id: 'gestion', title: 'Gestión · Back Office', ids: ['ventas', 'compras', 'finanzas', 'contabilidad', 'crm', 'rrhh', 'proyectos'] },
  { id: 'transversal', title: 'Capas transversales', ids: ['bi', 'mantenimiento', 'assistant', 'ia'] },
];

export function ConfigPanel({ model, onGenerate }: { model: PlantModel; onGenerate?: () => void }) {
  const { active, toggle, presetId, applyPreset, addModules, showOptional, setShowOptional, stage } = useStore();
  const preset = IND.presets.find((p) => p.id === presetId);
  const modified = preset && (preset.modules.length !== active.length || preset.modules.some((m) => !active.includes(m)));

  return (
    <div className="cfg">
      <div className="cfg-head">
        <div className="eyebrow">Configurá tu planta</div>
        <label className="preset-select">
          <span>Modelo inicial</span>
          <select value={presetId ?? 'personalizado'} onChange={(e) => applyPreset(e.target.value)}>
            {IND.presets.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
          </select>
        </label>
        {modified && <div className="muted small">Preset modificado: la combinación de checks define el recorrido.</div>}
      </div>

      {model.notices.length > 0 && (
        <div className="notices">
          {model.notices.map((n) => (
            <div key={n.id} className={`notice ${n.level}`}>
              <span className="dot" />
              <div>
                <div>{n.text}</div>
                {n.action && <button className="link" onClick={() => n.action?.add && addModules(n.action.add)}>{n.action.label}</button>}
              </div>
            </div>
          ))}
        </div>
      )}

      <div className="cfg-body">
        {GROUPS.map((g) => (
          <section key={g.id} className="cfg-group">
            <h4>{g.title}</h4>
            {g.ids.map((id) => {
              const m = IND.modules.find((x) => x.id === id)!;
              const on = active.includes(id);
              const auto = !on && model.autoAdded.includes(id);
              return (
                <label key={id} className={`mod-row ${on || auto ? 'on' : ''}`} title={m.shortDescription}>
                  <span className={`switch ${on || auto ? 'on' : ''}`} onClick={(e) => { e.preventDefault(); toggle(id); }}>
                    <span />
                  </span>
                  <span className="mod-text" onClick={(e) => { e.preventDefault(); toggle(id); }}>
                    <span className="mod-name">{m.name}{auto && <em className="tag auto">auto</em>}</span>
                    <span className="mod-desc">{m.shortDescription}</span>
                  </span>
                  <span className="tag">{CATEGORY_LABEL[m.category]}</span>
                </label>
              );
            })}
          </section>
        ))}
        <label className="opt-row">
          <input type="checkbox" checked={showOptional} onChange={(e) => setShowOptional(e.target.checked)} />
          Mostrar también hardware opcional
        </label>
      </div>

      {stage === 'config' && onGenerate && (
        <div className="cfg-foot">
          <button className="btn-primary wide" disabled={!active.length} onClick={onGenerate}>Generar planta</button>
        </div>
      )}
    </div>
  );
}
