import { create } from 'zustand';
import type { Layer, PlantRenderer } from './scene/renderer';
import { frigorifico } from './data/frigorifico';

export type Stage = 'intro' | 'preset' | 'config' | 'plant';

interface State {
  stage: Stage;
  presetId: string | null;
  active: string[];
  layer: Layer;
  showOptional: boolean;
  selectedSector: string | null;
  selectedHw: string | null;
  buildPhase: string | null;
  drawerOpen: boolean;
  summaryOpen: boolean;
  matrixOpen: boolean;
  setStage: (s: Stage) => void;
  applyPreset: (id: string) => void;
  toggle: (id: string, on?: boolean) => void;
  addModules: (ids: string[]) => void;
  setLayer: (l: Layer) => void;
  setShowOptional: (v: boolean) => void;
  selectSector: (id: string | null) => void;
  selectHw: (key: string | null) => void;
  setBuildPhase: (p: string | null) => void;
  setDrawer: (v: boolean) => void;
  setSummary: (v: boolean) => void;
  setMatrix: (v: boolean) => void;
}

export const useStore = create<State>((set) => ({
  stage: 'intro',
  presetId: null,
  active: [],
  layer: 'planta',
  showOptional: false,
  selectedSector: null,
  selectedHw: null,
  buildPhase: null,
  drawerOpen: false,
  summaryOpen: false,
  matrixOpen: false,
  setStage: (stage) => set({ stage }),
  applyPreset: (id) => {
    const p = frigorifico.presets.find((x) => x.id === id)!;
    set({ presetId: id, active: [...p.modules], selectedSector: null, selectedHw: null });
  },
  toggle: (id, on) => set((s) => {
    const has = s.active.includes(id);
    const want = on ?? !has;
    if (want === has) return {};
    return { active: want ? [...s.active, id] : s.active.filter((x) => x !== id) };
  }),
  addModules: (ids) => set((s) => ({ active: [...new Set([...s.active, ...ids])] })),
  setLayer: (layer) => set({ layer }),
  setShowOptional: (showOptional) => set({ showOptional }),
  selectSector: (selectedSector) => set({ selectedSector, selectedHw: null }),
  selectHw: (selectedHw) => set({ selectedHw }),
  setBuildPhase: (buildPhase) => set({ buildPhase }),
  setDrawer: (drawerOpen) => set({ drawerOpen }),
  setSummary: (summaryOpen) => set({ summaryOpen }),
  setMatrix: (matrixOpen) => set({ matrixOpen }),
}));

/** Acceso imperativo a la escena (no reactivo) */
export const sceneApi: { r: PlantRenderer | null } = { r: null };
