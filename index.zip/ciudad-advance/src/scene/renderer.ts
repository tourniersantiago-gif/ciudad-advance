// Renderer 2.5D isométrico sobre Canvas 2D.
// Un único loop rAF, sin assets externos: toda la planta se genera desde los datos.
import type { PlantModel, PlacedSector, PathSeg, HwPlacement } from '../engine/plant';
import type { Industry, FlowItem } from '../data/types';
import { iso, box, poly, floorQuad, line3, easeInOut, easeOut, clamp01, mkPoly, samplePoly, ZH } from './iso';
import type { Poly3 } from './iso';
import { C, drawPerson, drawCattle, drawTruck, drawItem, drawHardware, drawProp, drawRail, drawConveyor, roundRect } from './draw';

export type Layer = 'planta' | 'recorrido' | 'advance' | 'headway' | 'trazabilidad';

type Phase = 'floor' | 'walls' | 'lines' | 'machines' | 'devices' | 'people' | 'route';
const PH: Record<Phase, [number, number]> = {
  floor: [0, 0.18], walls: [0.12, 0.36], lines: [0.32, 0.5], machines: [0.46, 0.64], devices: [0.6, 0.78], people: [0.74, 0.9], route: [0.86, 1],
};
const PHASE_LABEL: [number, string][] = [
  [0.12, 'Preparando el terreno'], [0.34, 'Levantando paredes'], [0.48, 'Instalando rieleras y líneas'],
  [0.62, 'Ubicando máquinas'], [0.76, 'Conectando dispositivos Headway'], [0.88, 'Sumando operarios'], [1.01, 'Activando el recorrido'],
];

interface SState { ps: PlacedSector; x: number; y: number; born: number; dur: number; dying: number | null }
interface Drawable { k: number; tag: string; f: () => void }
interface Hit { kind: 'hw' | 'sector'; id: string; sectorId: string; sx: number; sy: number; r?: number; poly?: [number, number][]; rect?: [number, number, number, number] }

export interface RendererCallbacks {
  onSelectSector: (id: string | null) => void;
  onSelectHardware: (key: string) => void;
  onBuildPhase: (label: string | null) => void;
}

const HOT_Z: Record<string, number> = { station: 1.95, scale: 1.25, scan: 1.35, operator: 1.95, railscale: 2.75, desk: 1.45, counter: 1.65, selfcheckout: 1.75 };

export class PlantRenderer {
  private ctx: CanvasRenderingContext2D;
  private dpr = 1;
  private W = 0; private H = 0;
  private raf = 0;
  private now = 0;
  private last = 0;
  private model: PlantModel | null = null;
  private states = new Map<string, SState>();
  private routePoly: { poly: Poly3; segs: { from: number; to: number; item: FlowItem; kind: string }[] } | null = null;
  private branchPolys: { poly: Poly3; item: FlowItem; kind: string }[] = [];
  private techTour: Poly3 | null = null;
  private bounds = { minX: 0, minY: 0, maxX: 20, maxY: 20 };
  private cam = { x: 0, y: 0, z: 1 };
  private tween: { from: { x: number; y: number; z: number }; to: { x: number; y: number; z: number }; t0: number; dur: number } | null = null;
  private pad = { l: 0, r: 0, t: 0, b: 0 };
  private hits: Hit[] = [];
  private buildStart = -1;
  private lastPhase: string | null = null;
  layer: Layer = 'planta';
  selectedSector: string | null = null;
  selectedHw: string | null = null;
  hoverHit: Hit | null = null;
  showLabels = true;
  private pointers = new Map<number, { x: number; y: number }>();
  private drag: { x: number; y: number; cx: number; cy: number; moved: boolean } | null = null;
  private pinch: { d: number; z: number } | null = null;

  private canvas: HTMLCanvasElement;
  private ind: Industry;
  private cb: RendererCallbacks;
  private abort = new AbortController();

  constructor(canvas: HTMLCanvasElement, ind: Industry, cb: RendererCallbacks) {
    this.canvas = canvas; this.ind = ind; this.cb = cb;
    this.ctx = canvas.getContext('2d')!;
    this.resize();
    this.bindInput();
    const loop = (ts: number) => { if (this.raf === -1) return; this.frame(ts); this.raf = requestAnimationFrame(loop); };
    this.raf = requestAnimationFrame(loop);
  }

  destroy() { cancelAnimationFrame(this.raf); this.raf = -1; this.abort.abort(); }

  resize() {
    const r = this.canvas.getBoundingClientRect();
    this.dpr = Math.min(window.devicePixelRatio || 1, 2);
    this.W = r.width; this.H = r.height;
    this.canvas.width = Math.max(1, r.width * this.dpr);
    this.canvas.height = Math.max(1, r.height * this.dpr);
  }

  setPadding(p: { l: number; r: number; t: number; b: number }) { this.pad = p; }

  // ─────────── modelo ───────────
  setModel(m: PlantModel, mode: 'build' | 'update' | 'silent') {
    const t = performance.now();
    this.model = m;
    if (mode === 'build' || mode === 'silent') {
      this.states.clear();
      m.sectors.forEach((ps, i) => this.states.set(ps.id, { ps, x: ps.gx, y: ps.gy, born: mode === 'silent' ? t - 10000 : t + i * 70, dur: 3000, dying: null }));
      if (mode === 'build') this.buildStart = t;
      this.bounds = { ...m.bounds };
    } else {
      const ids = new Set(m.sectors.map((s) => s.id));
      this.states.forEach((s, id) => { if (!ids.has(id) && s.dying === null) s.dying = t; });
      m.sectors.forEach((ps) => {
        const s = this.states.get(ps.id);
        if (s && s.dying === null) s.ps = ps;
        else this.states.set(ps.id, { ps, x: ps.gx, y: ps.gy, born: t, dur: 1500, dying: null });
      });
    }
    // trayectorias
    const segs = m.routeSegs;
    if (segs.length) {
      const pts: { x: number; y: number; z: number }[] = [];
      const meta: { from: number; to: number; item: FlowItem; kind: string }[] = [];
      segs.forEach((sg) => {
        const startIdx = pts.length ? pts.length - 1 : 0;
        sg.pts.forEach((p, i) => { if (i === 0 && pts.length) return; pts.push(p); });
        meta.push({ from: startIdx, to: pts.length - 1, item: sg.item, kind: sg.kind });
      });
      const poly = mkPoly(pts);
      this.routePoly = { poly, segs: meta };
    } else this.routePoly = null;
    this.branchPolys = m.branchSegs.map((b: PathSeg) => ({ poly: mkPoly(b.pts), item: b.item, kind: b.kind }));
    // recorrida del técnico de mantenimiento
    const main = m.sectors.filter((s) => s.sector.lane === 'main');
    const taller = m.sectors.find((s) => s.id === 'taller');
    if (taller && main.length) {
      const pts = [{ x: taller.gx + 2, y: taller.gy + 4.6, z: 0 }];
      main.forEach((s) => pts.push({ x: s.gx + s.sector.size.w / 2, y: s.gy + s.sector.size.d + 1.6, z: 0 }));
      this.techTour = mkPoly(pts);
    } else this.techTour = null;
    if (mode !== 'silent') setTimeout(() => this.fitAll(true), mode === 'build' ? 0 : 250);
    else this.fitAll(false);
  }

  // ─────────── cámara ───────────
  private isoBounds(minX: number, minY: number, maxX: number, maxY: number, zTop = 3) {
    const pts = [iso(minX, minY, 0), iso(maxX, minY, 0), iso(maxX, maxY, 0), iso(minX, maxY, 0), iso(minX, minY, zTop), iso(maxX, minY, zTop)];
    const xs = pts.map((p) => p[0]), ys = pts.map((p) => p[1]);
    return { x0: Math.min(...xs), x1: Math.max(...xs), y0: Math.min(...ys), y1: Math.max(...ys) };
  }
  private camTo(x: number, y: number, z: number, animate: boolean, dur = 1000) {
    if (!animate) { this.cam = { x, y, z }; this.tween = null; return; }
    this.tween = { from: { ...this.cam }, to: { x, y, z }, t0: performance.now(), dur };
  }
  private viewport() {
    const w = Math.max(200, this.W - this.pad.l - this.pad.r), h = Math.max(200, this.H - this.pad.t - this.pad.b);
    return { w, h, cx: this.pad.l + w / 2, cy: this.pad.t + h / 2 };
  }
  fitAll(animate = true) {
    if (!this.model) return;
    const b = this.model.bounds;
    const ib = this.isoBounds(b.minX, b.minY, b.maxX, b.maxY);
    const vp = this.viewport();
    const z = Math.min(vp.w / (ib.x1 - ib.x0), vp.h / (ib.y1 - ib.y0)) * 0.98;
    const cx = (ib.x0 + ib.x1) / 2, cy = (ib.y0 + ib.y1) / 2;
    // centro desplazado según el padding
    const ox = (vp.cx - this.W / 2) / z, oy = (vp.cy - this.H / 2) / z;
    this.camTo(cx - ox, cy - oy, Math.min(z, 1.6), animate);
  }
  focusSector(id: string) {
    const s = this.states.get(id);
    if (!s) return;
    const { w, d } = s.ps.sector.size;
    const ib = this.isoBounds(s.ps.gx - 1.2, s.ps.gy - 1.2, s.ps.gx + w + 1.2, s.ps.gy + d + 1.2, s.ps.sector.wallHeight + 0.8);
    const vp = this.viewport();
    const z = Math.min(2.6, Math.min(vp.w / (ib.x1 - ib.x0), vp.h / (ib.y1 - ib.y0)) * 0.9);
    const ox = (vp.cx - this.W / 2) / z, oy = (vp.cy - this.H / 2) / z;
    this.camTo((ib.x0 + ib.x1) / 2 - ox, (ib.y0 + ib.y1) / 2 - oy, z, true, 1100);
  }
  zoomBy(f: number) {
    const z = Math.max(0.25, Math.min(4, this.cam.z * f));
    this.camTo(this.cam.x, this.cam.y, z, true, 350);
  }
  private toScreen(x: number, y: number, z: number): [number, number] {
    const [ix, iy] = iso(x, y, z);
    return [(ix - this.cam.x) * this.cam.z + this.W / 2, (iy - this.cam.y) * this.cam.z + this.H / 2];
  }

  // ─────────── input ───────────
  private bindInput() {
    const c = this.canvas;
    const opt = { signal: this.abort.signal };
    c.addEventListener('pointerdown', (e) => {
      c.setPointerCapture(e.pointerId);
      this.pointers.set(e.pointerId, { x: e.offsetX, y: e.offsetY });
      if (this.pointers.size === 1) this.drag = { x: e.offsetX, y: e.offsetY, cx: this.cam.x, cy: this.cam.y, moved: false };
      if (this.pointers.size === 2) {
        const [a, b] = [...this.pointers.values()];
        this.pinch = { d: Math.hypot(a.x - b.x, a.y - b.y), z: this.cam.z };
        this.drag = null;
      }
    }, opt);
    c.addEventListener('pointermove', (e) => {
      if (this.pointers.has(e.pointerId)) this.pointers.set(e.pointerId, { x: e.offsetX, y: e.offsetY });
      if (this.pinch && this.pointers.size === 2) {
        const [a, b] = [...this.pointers.values()];
        const d = Math.hypot(a.x - b.x, a.y - b.y);
        this.cam.z = Math.max(0.25, Math.min(4, this.pinch.z * (d / this.pinch.d)));
        this.tween = null;
        return;
      }
      if (this.drag) {
        const dx = e.offsetX - this.drag.x, dy = e.offsetY - this.drag.y;
        if (Math.abs(dx) + Math.abs(dy) > 5) this.drag.moved = true;
        if (this.drag.moved) { this.tween = null; this.cam.x = this.drag.cx - dx / this.cam.z; this.cam.y = this.drag.cy - dy / this.cam.z; }
        return;
      }
      this.hoverHit = this.hitTest(e.offsetX, e.offsetY);
      c.style.cursor = this.hoverHit ? 'pointer' : 'grab';
    }, opt);
    const up = (e: PointerEvent) => {
      const wasDrag = this.drag;
      this.pointers.delete(e.pointerId);
      if (this.pointers.size < 2) this.pinch = null;
      if (wasDrag && !wasDrag.moved && this.pointers.size === 0) {
        const h = this.hitTest(e.offsetX, e.offsetY);
        if (h?.kind === 'hw') this.cb.onSelectHardware(h.id);
        else if (h?.kind === 'sector') this.cb.onSelectSector(h.sectorId);
      }
      this.drag = null;
    };
    c.addEventListener('pointerup', up, opt);
    c.addEventListener('pointercancel', up, opt);
    c.addEventListener('wheel', (e) => {
      e.preventDefault();
      const f = Math.exp(-e.deltaY * 0.0015);
      const z0 = this.cam.z, z1 = Math.max(0.25, Math.min(4, z0 * f));
      // zoom hacia el cursor
      const wx = (e.offsetX - this.W / 2) / z0 + this.cam.x, wy = (e.offsetY - this.H / 2) / z0 + this.cam.y;
      this.cam.z = z1;
      this.cam.x = wx - (e.offsetX - this.W / 2) / z1;
      this.cam.y = wy - (e.offsetY - this.H / 2) / z1;
      this.tween = null;
    }, { passive: false, signal: this.abort.signal });
  }

  private hitTest(x: number, y: number): Hit | null {
    let best: Hit | null = null; let bd = 1e9;
    for (const h of this.hits) {
      if (h.kind === 'hw') {
        const d = Math.hypot(h.sx - x, h.sy - y);
        if (d < (h.r ?? 14) && d < bd) { best = h; bd = d; }
      }
    }
    if (best) return best;
    for (const h of this.hits) if (h.rect) { const [rx, ry, rw, rh] = h.rect; if (x >= rx && x <= rx + rw && y >= ry && y <= ry + rh) return h; }
    for (let i = this.hits.length - 1; i >= 0; i--) { const h = this.hits[i]; if (h.poly && pip(x, y, h.poly)) return h; }
    return null;
  }

  // ─────────── frame ───────────
  private phase(s: SState, ph: Phase): number {
    const lp = clamp01((this.now - s.born) / s.dur);
    const [a, b] = PH[ph];
    let v = easeOut(clamp01((lp - a) / (b - a)));
    if (s.dying !== null) v *= 1 - clamp01((this.now - s.dying) / 500);
    return v;
  }

  private frame(ts: number) {
    const dt = Math.min(0.05, (ts - (this.last || ts)) / 1000);
    this.last = ts; this.now = performance.now();
    const t = this.now / 1000;
    const ctx = this.ctx;
    if (this.tween) {
      const k = easeInOut(clamp01((this.now - this.tween.t0) / this.tween.dur));
      const { from, to } = this.tween;
      this.cam.x = from.x + (to.x - from.x) * k;
      this.cam.y = from.y + (to.y - from.y) * k;
      this.cam.z = Math.exp(Math.log(from.z) + (Math.log(to.z) - Math.log(from.z)) * k);
      if (k >= 1) this.tween = null;
    }
    // limpiar muertos, interpolar posiciones y bounds
    this.states.forEach((s, id) => {
      if (s.dying !== null && this.now - s.dying > 520) this.states.delete(id);
      s.x += (s.ps.gx - s.x) * Math.min(1, dt * 5);
      s.y += (s.ps.gy - s.y) * Math.min(1, dt * 5);
    });
    if (this.model) {
      const mb = this.model.bounds, b = this.bounds, k = Math.min(1, dt * 4);
      b.minX += (mb.minX - b.minX) * k; b.minY += (mb.minY - b.minY) * k; b.maxX += (mb.maxX - b.maxX) * k; b.maxY += (mb.maxY - b.maxY) * k;
    }
    // fase de construcción para la UI
    if (this.buildStart > 0) {
      const lp = (this.now - this.buildStart) / 3300;
      const label = lp >= 1.05 ? null : (PHASE_LABEL.find(([th]) => lp < th)?.[1] ?? null);
      if (label !== this.lastPhase) { this.lastPhase = label; this.cb.onBuildPhase(label); }
      if (lp >= 1.05) this.buildStart = -1;
    }

    ctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
    const g = ctx.createLinearGradient(0, 0, 0, this.H);
    g.addColorStop(0, '#f7f8fb'); g.addColorStop(1, '#eceff4');
    ctx.fillStyle = g; ctx.fillRect(0, 0, this.W, this.H);
    const z = this.cam.z;
    ctx.setTransform(this.dpr * z, 0, 0, this.dpr * z, this.dpr * (this.W / 2 - this.cam.x * z), this.dpr * (this.H / 2 - this.cam.y * z));
    this.hits = [];
    if (!this.model) return;

    this.drawGround(t);
    const list: Drawable[] = [];
    const sorted = [...this.states.values()].sort((a, b) => (a.x + a.y) - (b.x + b.y));
    sorted.forEach((s) => this.drawFloor(s));
    this.drawCorridors(t);
    sorted.forEach((s) => this.collectSector(s, list, t));
    this.collectFlow(list, t);
    list.sort((a, b) => a.k - b.k);
    for (const d of list) d.f();
    ctx.globalAlpha = 1;

    // ─── capas ───
    const L = this.layer;
    if (L !== 'planta') {
      ctx.save(); ctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
      ctx.fillStyle = 'rgba(244,245,249,0.62)'; ctx.fillRect(0, 0, this.W, this.H);
      ctx.restore();
      if (L === 'recorrido' || L === 'trazabilidad') {
        this.drawRouteLine(t, L === 'trazabilidad');
        for (const d of list) if (d.tag === 'item') d.f();
      }
      if (L === 'headway') for (const d of list) if (d.tag === 'hw' || d.tag === 'holder' || d.tag === 'hwscreen') d.f();
      if (L === 'advance') { this.drawAdvanceLinks(t); for (const d of list) if (d.tag === 'screen' || d.tag === 'hwscreen') d.f(); }
      ctx.globalAlpha = 1;
    }

    // ─── overlays en pantalla ───
    ctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
    this.drawOverlays(t);
  }

  private drawGround(t: number) {
    const ctx = this.ctx, b = this.bounds;
    const pts = [iso(b.minX, b.minY), iso(b.maxX, b.minY), iso(b.maxX, b.maxY), iso(b.minX, b.maxY)];
    ctx.save();
    ctx.shadowColor = 'rgba(40,50,80,0.12)'; ctx.shadowBlur = 40; ctx.shadowOffsetY = 18;
    poly(ctx, pts, '#e7eaf0');
    ctx.restore();
    // canto del terreno
    poly(ctx, [iso(b.minX, b.maxY), iso(b.maxX, b.maxY), iso(b.maxX, b.maxY, -0.35), iso(b.minX, b.maxY, -0.35)], '#d5dae3');
    poly(ctx, [iso(b.maxX, b.minY), iso(b.maxX, b.maxY), iso(b.maxX, b.maxY, -0.35), iso(b.maxX, b.minY, -0.35)], '#c9cfd9');
    ctx.strokeStyle = 'rgba(160,170,190,0.18)'; ctx.lineWidth = 1;
    ctx.beginPath();
    for (let x = Math.ceil(b.minX); x <= b.maxX; x += 2) { const a = iso(x, b.minY), c = iso(x, b.maxY); ctx.moveTo(a[0], a[1]); ctx.lineTo(c[0], c[1]); }
    for (let y = Math.ceil(b.minY); y <= b.maxY; y += 2) { const a = iso(b.minX, y), c = iso(b.maxX, y); ctx.moveTo(a[0], a[1]); ctx.lineTo(c[0], c[1]); }
    ctx.stroke();
  }

  private drawFloor(s: SState) {
    const ctx = this.ctx, ps = s.ps, { w, d } = ps.sector.size;
    const a = this.phase(s, 'floor');
    if (a <= 0) return;
    ctx.globalAlpha = a;
    const k = ps.sector.kind;
    const fill = k === 'yard' ? '#e4dccd' : k === 'office' ? '#f1ece4' : k === 'store' ? '#f5efe8' : k === 'portal' ? 'rgba(255,255,255,0.4)' : ps.sector.cold ? '#eaf0f6' : '#f3f5f8';
    const sink = (1 - a) * 0.6;
    floorQuad(ctx, s.x, s.y, w, d, 0.02 - sink, fill, k === 'portal' ? undefined : 'rgba(150,160,180,0.35)');
    if (k !== 'yard' && k !== 'portal') {
      ctx.strokeStyle = 'rgba(160,170,190,0.16)'; ctx.lineWidth = 0.8; ctx.beginPath();
      for (let i = 1; i < w; i++) { const p = iso(s.x + i, s.y, 0.02), q = iso(s.x + i, s.y + d, 0.02); ctx.moveTo(p[0], p[1]); ctx.lineTo(q[0], q[1]); }
      for (let j = 1; j < d; j++) { const p = iso(s.x, s.y + j, 0.02), q = iso(s.x + w, s.y + j, 0.02); ctx.moveTo(p[0], p[1]); ctx.lineTo(q[0], q[1]); }
      ctx.stroke();
    }
    const sel = this.selectedSector === ps.id;
    const hov = this.hoverHit?.kind === 'sector' && this.hoverHit.sectorId === ps.id;
    if (sel || hov) {
      ctx.save();
      ctx.shadowColor = C.magenta; ctx.shadowBlur = sel ? 14 : 6;
      floorQuad(ctx, s.x - 0.05, s.y - 0.05, w + 0.1, d + 0.1, 0.03, undefined as unknown as string, sel ? C.magenta : 'rgba(230,0,126,0.45)');
      ctx.restore();
    }
    ctx.globalAlpha = 1;
    // hit poly
    this.hits.push({ kind: 'sector', id: ps.id, sectorId: ps.id, sx: 0, sy: 0, poly: [this.toScreen(s.x, s.y, 0), this.toScreen(s.x + w, s.y, 0), this.toScreen(s.x + w, s.y + d, 0), this.toScreen(s.x, s.y + d, 0)] });
  }

  private routeAlpha(): number {
    let a = 1;
    this.states.forEach((s) => { if (s.ps.routeIndex !== null) a = Math.min(a, this.phase(s, 'route')); });
    return a;
  }

  private drawCorridors(t: number) {
    const ctx = this.ctx;
    const ra = this.routeAlpha();
    if (ra <= 0) return;
    ctx.globalAlpha = ra;
    this.model?.routeSegs.forEach((sg) => {
      if (sg.kind === 'corridor') {
        const pts = sg.pts.map((p) => ({ ...p, z: 0.03 }));
        line3(ctx, pts, '#dde1e8', 18);
        line3(ctx, pts, '#f7f8fa', 12);
        const zc = sg.pts[0].z;
        for (let i = 1; i < sg.pts.length; i++) {
          const a = sg.pts[i - 1], b = sg.pts[i];
          if (zc > 1.5) drawRail(ctx, a, b, zc, true);
          else if (zc > 0.3) {
            const x0 = Math.min(a.x, b.x), y0 = Math.min(a.y, b.y);
            const alongX = Math.abs(b.x - a.x) > Math.abs(b.y - a.y);
            const wv = alongX ? Math.abs(b.x - a.x) : 0.8, dv = alongX ? 0.8 : Math.abs(b.y - a.y);
            const bx = alongX ? x0 : x0 - 0.4, by = alongX ? y0 - 0.4 : y0;
            const nLeg = Math.max(1, Math.round(Math.max(wv, dv) / 1.5));
            for (let k = 0; k <= nLeg; k++) { const f = k / nLeg; box(ctx, bx + (alongX ? f * wv : 0.35) - 0.05, by + (alongX ? 0.35 : f * dv) - 0.05, 0, 0.1, 0.1, zc - 0.14, C.steelDark); }
            box(ctx, bx, by, zc - 0.14, wv, dv, 0.14, C.steel, { top: C.belt });
          }
        }
      }
      if (sg.kind === 'distribution') {
        line3(ctx, sg.pts.map((p) => ({ ...p, z: 0.02 })), '#d3d8e0', 26);
        line3(ctx, sg.pts.map((p) => ({ ...p, z: 0.03 })), '#ffffff', 1.5, [10, 10]);
      }
    });
    this.branchPolys.forEach((b) => {
      if (b.kind === 'branch') line3(ctx, b.poly.pts.map((p) => ({ ...p, z: 0.03 })), '#e3e6ec', 12);
      if (b.kind === 'order') line3(ctx, b.poly.pts, 'rgba(230,0,126,0.25)', 1.5, [4, 6], -t * 20);
    });
    ctx.globalAlpha = 1;
  }

  /** Convierte coordenadas locales de sector a mundo, aplicando espejo */
  private wx(s: SState, lx: number, w = 0) { return s.x + (s.ps.mirror ? s.ps.sector.size.w - lx - w : lx); }

  private collectSector(s: SState, list: Drawable[], t: number) {
    const ctx = this.ctx, ps = s.ps, sec = ps.sector, { w, d } = sec.size;
    const flags = this.model!.flags;
    const base = s.x + s.y;
    const ph = (p: Phase) => this.phase(s, p);
    const withA = (a: number, rise: number, f: () => void) => () => {
      if (a <= 0.01) return;
      ctx.globalAlpha = a;
      if (rise) { ctx.save(); ctx.translate(0, -(1 - a) * rise); f(); ctx.restore(); } else f();
      ctx.globalAlpha = 1;
    };

    // ── paredes ──
    if (sec.walls) {
      const aw = ph('walls');
      const H = sec.wallHeight * aw;
      const col = sec.kind === 'office' ? '#fdfcfa' : sec.cold ? '#f6f9fc' : C.wall;
      const fy = sec.flowPath.length ? sec.flowPath[0][1] : d / 2;
      const isMain = sec.lane === 'main';
      list.push({ k: base - 1, tag: 'wall', f: withA(Math.min(1, aw * 1.5), 0, () => {
        // pared de fondo (y = 0)
        box(ctx, s.x, s.y, 0, w, 0.14, H, col, { stroke: 'rgba(0,0,0,0.05)' });
        // pared lateral (x = 0) con abertura de flujo
        if (isMain) {
          box(ctx, s.x, s.y, 0, 0.14, fy - 0.9, H, col, { stroke: 'rgba(0,0,0,0.05)' });
          box(ctx, s.x, s.y + fy + 0.9, 0, 0.14, d - fy - 0.9, H, col, { stroke: 'rgba(0,0,0,0.05)' });
        } else box(ctx, s.x, s.y, 0, 0.14, d, H, col, { stroke: 'rgba(0,0,0,0.05)' });
        if (sec.kind === 'office' || sec.kind === 'store') {
          ctx.globalAlpha *= 0.9;
          poly(ctx, [iso(s.x + 0.5, s.y + 0.15, H * 0.35), iso(s.x + w - 0.5, s.y + 0.15, H * 0.35), iso(s.x + w - 0.5, s.y + 0.15, H * 0.85), iso(s.x + 0.5, s.y + 0.15, H * 0.85)], 'rgba(160,200,230,0.45)');
        }
        if (sec.cold) { // franja de panel frigorífico
          const a1 = iso(s.x + 0.2, s.y + 0.15, H * 0.9), a2 = iso(s.x + w - 0.2, s.y + 0.15, H * 0.9);
          ctx.strokeStyle = 'rgba(120,170,210,0.35)'; ctx.lineWidth = 1.4; ctx.beginPath(); ctx.moveTo(a1[0], a1[1]); ctx.lineTo(a2[0], a2[1]); ctx.stroke();
        }
      }) });
      // paredes frontales bajas (corte de maqueta)
      const lowH = 0.3 * aw;
      list.push({ k: base + w + d + 0.5, tag: 'wall', f: withA(Math.min(1, aw * 1.5), 0, () => {
        const doorL = w / 2 - 0.7, doorR = w / 2 + 0.7;
        box(ctx, s.x, s.y + d - 0.12, 0, doorL, 0.12, lowH, col);
        box(ctx, s.x + doorR, s.y + d - 0.12, 0, w - doorR, 0.12, lowH, col);
        if (isMain) {
          box(ctx, s.x + w - 0.12, s.y, 0, 0.12, fy - 0.9, lowH, col);
          box(ctx, s.x + w - 0.12, s.y + fy + 0.9, 0, 0.12, d - fy - 0.9 - 0.12, lowH, col);
        } else box(ctx, s.x + w - 0.12, s.y, 0, 0.12, d - 0.12, lowH, col);
      }) });
    }

    // ── rieles / cintas propias del flujo ──
    if (sec.flowZ > 1.5 && sec.flowPath.length >= 2) {
      const al = ph('lines');
      const [p0, p1] = [sec.flowPath[0], sec.flowPath[sec.flowPath.length - 1]];
      const n = Math.ceil(Math.abs(p1[0] - p0[0]));
      for (let i = 0; i < n; i++) {
        const xa = this.wx(s, p0[0] + i), xb = this.wx(s, Math.min(p1[0], p0[0] + i + 1));
        const y = s.y + p0[1];
        list.push({ k: (xa + xb) / 2 + y + 0.4, tag: 'line', f: withA(al, 30, () => drawRail(ctx, { x: xa, y }, { x: xb, y }, sec.flowZ, i % 2 === 0)) });
      }
    }

    // ── props ──
    sec.props.forEach((p, i) => {
      if (p.when && !flags[p.when]) return;
      const pw = p.w ?? 1, pd = p.d ?? 1, phh = p.h ?? 1;
      const X = this.wx(s, p.x, ['cattle', 'truck'].includes(p.type) ? 0 : pw);
      const Y = s.y + p.y;
      if (p.type === 'conveyor') {
        const n = Math.ceil(pw);
        const al = ph('lines');
        for (let k = 0; k < n; k++) {
          const cw = Math.min(1, pw - k);
          const cx = s.ps.mirror ? X + pw - k - cw : X + k;
          list.push({ k: cx + cw / 2 + Y + pd / 2 - 0.35, tag: 'line', f: withA(al, 30, () => drawConveyor(ctx, cx, Y, cw, pd, ps.mirror ? -t : t)) });
        }
        return;
      }
      if (p.type === 'cattle') {
        const wxp = X + Math.sin(t * 0.35 + i) * 0.5, wyp = Y + Math.cos(t * 0.27 + i * 2) * 0.35;
        list.push({ k: wxp + wyp, tag: 'person', f: withA(ph('people'), 20, () => drawCattle(ctx, wxp, wyp, t, i, Math.cos(t * 0.35 + i) > 0 ? 1 : -1)) });
        return;
      }
      if (p.type === 'truck') { this.collectTruck(s, p.x, p.y, p.v ?? 'in', list, t, i); return; }
      if (p.type === 'forklift') {
        const span = 5.6, per = 9;
        const k = (t % per) / per; const f = k < 0.5 ? k * 2 : 2 - k * 2;
        const lx = 1 + easeInOut(f) * span;
        const fx = this.wx(s, lx), fy = Y;
        list.push({ k: fx + fy + 0.3, tag: 'person', f: withA(ph('people'), 20, () => drawForklift(ctx, fx, fy, k < 0.5 !== ps.mirror ? 1 : -1, k < 0.5)) });
        return;
      }
      if (p.type === 'portal') {
        list.push({ k: X + Y, tag: 'screen', f: withA(ph('machines'), 30, () => drawProp(ctx, 'portal', s.x + p.x, Y, 0, 0, 0, p.v, t, i, ps.mirror)) });
        return;
      }
      const tag = ['desk', 'bigscreen'].includes(p.type) ? 'screen' : 'prop';
      list.push({ k: X + pw / 2 + Y + pd / 2 - (p.type === 'rack' ? 0.4 : 0), tag, f: withA(ph('machines'), 30, () => drawProp(ctx, p.type, X, Y, pw, pd, phh, p.v, t, i, ps.mirror)) });
    });

    // ── hardware ──
    const hwList = this.model!.hardware.filter((h) => h.sectorId === ps.id && h.pos && h.operatorIndex === undefined);
    hwList.forEach((h, i) => {
      const hw = this.ind.hardware.find((x) => x.id === h.hwId)!;
      const pos = h.pos!;
      const hx = pos.x + (s.x - ps.gx), hy = pos.y + (s.y - ps.gy);
      const a = ph('devices');
      const tag = ['terminal', 'pos', 'smartpos', 'minipc', 'selfcheckout'].includes(hw.family) ? 'hwscreen' : 'hw';
      list.push({ k: hx + hy + 0.05 + (hw.family === 'rail_scale' ? 0.5 : 0), tag, f: withA(a, 24, () => drawHardware(ctx, hw.family, hx, hy, pos.z, t, i)) });
      if (a > 0.5) this.pushHwHit(h, hx, hy, HOT_Z[h.anchor] ?? 1.5);
    });

    // ── operarios ──
    const ap = ph('people');
    const holders = new Map<number, HwPlacement>();
    this.model!.hardware.forEach((h) => { if (h.sectorId === ps.id && h.operatorIndex !== undefined && h.pos) holders.set(h.operatorIndex, h); });
    sec.operators.forEach((o, i) => {
      let lx = o.x, ly = o.y, walking = false;
      let ox: number, oy: number;
      if (o.role === 'tech' && this.techTour) {
        const L = this.techTour.len, per = L * 1.6;
        const k = (t % per) / per; const f = k < 0.5 ? k * 2 : 2 - k * 2;
        const sp = samplePoly(this.techTour, f * L);
        ox = sp.x; oy = sp.y; walking = true;
      } else {
        if (o.walk) {
          const [a, b] = o.walk; const L = Math.hypot(b[0] - a[0], b[1] - a[1]); const per = L * 1.4 + 2;
          const k = ((t + i * 1.7) % per) / per; let f = k < 0.5 ? k * 2 : 2 - k * 2; f = clamp01(f * 1.15 - 0.075);
          lx = a[0] + (b[0] - a[0]) * f; ly = a[1] + (b[1] - a[1]) * f; walking = f > 0.01 && f < 0.99;
        }
        ox = this.wx(s, lx); oy = s.y + ly;
      }
      const holder = holders.get(i);
      const hw = holder ? this.ind.hardware.find((x) => x.id === holder.hwId)! : null;
      const device = hw ? (hw.family === 'tablet' ? 'tablet' : hw.family === 'glove' ? 'glove' : 'collector') : undefined;
      const fx = ox, fy = oy;
      list.push({ k: fx + fy + 0.1, tag: holder ? 'holder' : 'person', f: withA(ap, 24, () => drawPerson(ctx, fx, fy, o.role, t, i + ps.id.length, device, walking)) });
      if (holder && ap > 0.5) this.pushHwHit(holder, fx, fy, HOT_Z.operator);
    });

    // clientes de la carnicería
    if (ps.id === 'retail') {
      const path: [number, number][] = [[w / 2 + 0.3, d + 1.6], [w / 2 + 0.3, d - 0.4], [2.0, 2.5], [2.0, 2.4], [3.4, 4.3], [w / 2 + 0.8, d - 0.3], [w / 2 + 0.8, d + 1.6]];
      const pp = mkPoly(path.map(([x, y]) => ({ x: this.wx(s, x), y: s.y + y, z: 0 })));
      for (let c = 0; c < 2; c++) {
        const per = 16; const k = ((t + c * 8) % per) / per;
        const sp = samplePoly(pp, k * pp.len);
        const a = ap * (k < 0.06 ? k / 0.06 : k > 0.94 ? (1 - k) / 0.06 : 1);
        list.push({ k: sp.x + sp.y + 0.1, tag: 'person', f: withA(a, 0, () => drawPerson(ctx, sp.x, sp.y, 'customer', t, c + 3, undefined, true)) });
      }
    }
  }

  private collectTruck(s: SState, lx0: number, ly: number, v: string, list: Drawable[], t: number, i: number) {
    const ctx = this.ctx, ps = s.ps, W = ps.sector.size.w, L = 3.4;
    const per = v === 'cattle' || v === 'in' ? 16 : 18;
    const k = ((t + (v === 'out2' ? 7 : 0)) % per) / per;
    let lx = lx0, a = 1;
    if (v === 'cattle' || v === 'in') {
      if (k < 0.25) { const f = easeOut(k / 0.25); lx = lx0 - 5 + f * 5; a = clamp01(k / 0.08); }
      else if (k < 0.7) lx = lx0;
      else { const f = (k - 0.7) / 0.3; lx = lx0 - f * f * 6; a = 1 - clamp01((k - 0.9) / 0.1); }
    } else {
      if (k < 0.5) lx = lx0;
      else if (k < 0.72) { const f = (k - 0.5) / 0.22; lx = lx0 + f * f * 7; a = 1 - clamp01((f - 0.6) / 0.4); }
      else { const f = (k - 0.72) / 0.28; lx = lx0 + 7 - easeOut(f) * 7; a = clamp01(f / 0.3); }
    }
    const dirLocal = v === 'cattle' || v === 'in' ? 1 : 1;
    const X = ps.mirror ? s.x + W - lx - L : s.x + lx;
    const dir = ps.mirror ? -dirLocal : dirLocal;
    const Y = s.y + ly;
    list.push({ k: X + L / 2 + Y + 0.5, tag: 'prop', f: () => {
      const pa = this.phase(s, 'machines') * a;
      if (pa <= 0.01) return;
      ctx.globalAlpha = pa; drawTruck(ctx, X, Y, dir, v === 'cattle' ? 'cattle' : 'box'); ctx.globalAlpha = 1;
    } });
  }

  private pushHwHit(h: HwPlacement, x: number, y: number, z: number) {
    const [sx, sy] = this.toScreen(x, y, z);
    this.hits.push({ kind: 'hw', id: h.key, sectorId: h.sectorId, sx, sy, r: 16 });
  }

  private collectFlow(list: Drawable[], t: number) {
    const ctx = this.ctx;
    const ra = this.routeAlpha();
    if (ra <= 0.01) return;
    const rp = this.routePoly;
    if (rp) {
      const L = rp.poly.len;
      const spacing = 1.9;
      const n = Math.floor(L / spacing);
      const speed = 0.55;
      for (let i = 0; i < n; i++) {
        const s = (t * speed + i * spacing) % L;
        const sp = samplePoly(rp.poly, s);
        // segmento → ítem
        let idx = 1; while (idx < rp.poly.cum.length - 1 && rp.poly.cum[idx] < s) idx++;
        const seg = rp.segs.find((g) => idx > g.from && idx <= g.to) ?? rp.segs[rp.segs.length - 1];
        const isFirst = i === 0;
        list.push({ k: sp.x + sp.y + 0.2, tag: 'item', f: () => {
          ctx.globalAlpha = ra;
          drawItem(ctx, seg.item, sp.x, sp.y, sp.z, t, i, seg.kind);
          if (isFirst && this.layer === 'trazabilidad') {
            const [px, py] = iso(sp.x, sp.y, sp.z + 0.6);
            ctx.strokeStyle = C.magenta; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(px, py, 16 + Math.sin(t * 4) * 2, 0, Math.PI * 2); ctx.stroke();
            this.tracked = { x: sp.x, y: sp.y, z: sp.z, item: seg.item };
          }
          ctx.globalAlpha = 1;
        } });
      }
    }
    this.branchPolys.forEach((b, bi) => {
      const L = b.poly.len; if (L <= 0) return;
      const n = b.kind === 'order' ? 2 : Math.max(1, Math.floor(L / 3));
      for (let i = 0; i < n; i++) {
        const s = (t * (b.kind === 'order' ? 1.6 : 0.5) + i * (L / n) + bi) % L;
        const sp = samplePoly(b.poly, s);
        list.push({ k: sp.x + sp.y + 0.2 + (b.kind === 'order' ? 50 : 0), tag: 'item', f: () => { ctx.globalAlpha = ra; drawItem(ctx, b.item, sp.x, sp.y, sp.z, t, i); ctx.globalAlpha = 1; } });
      }
    });
  }
  private tracked: { x: number; y: number; z: number; item: FlowItem } | null = null;

  private drawRouteLine(t: number, thin: boolean) {
    const rp = this.routePoly; if (!rp) return;
    const ctx = this.ctx;
    const pts = rp.poly.pts.map((p) => ({ ...p, z: Math.min(p.z, 0.9) * 0.4 + 0.05 }));
    const a = iso(pts[0].x, pts[0].y, pts[0].z), b = iso(pts[pts.length - 1].x, pts[pts.length - 1].y, 0);
    const g = ctx.createLinearGradient(a[0], a[1], b[0], b[1]);
    g.addColorStop(0, C.magenta); g.addColorStop(0.55, C.red); g.addColorStop(1, C.orange);
    line3(ctx, pts, 'rgba(230,0,126,0.16)', thin ? 10 : 22);
    line3(ctx, pts, g as unknown as string, thin ? 3 : 6);
    line3(ctx, pts, 'rgba(255,255,255,0.9)', thin ? 1.2 : 2, [6, 14], -t * 40);
    this.branchPolys.forEach((bp) => line3(ctx, bp.poly.pts.map((p) => ({ ...p, z: bp.kind === 'order' ? p.z : 0.05 })), bp.kind === 'order' ? 'rgba(230,0,126,0.6)' : 'rgba(255,122,26,0.7)', 3, [8, 8], -t * 30));
  }

  private drawAdvanceLinks(t: number) {
    const ctx = this.ctx;
    ctx.save(); ctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
    const hub = this.advanceHub();
    this.states.forEach((s) => {
      if (!s.ps.modules.length && s.ps.id !== 'admin') return;
      const { w } = s.ps.sector.size;
      const [x, y] = this.toScreen(s.x + w / 2, s.y + 0.2, s.ps.sector.wallHeight + 0.2);
      const g = ctx.createLinearGradient(hub[0], hub[1], x, y);
      g.addColorStop(0, 'rgba(230,0,126,0.85)'); g.addColorStop(1, 'rgba(255,122,26,0.55)');
      ctx.strokeStyle = g; ctx.lineWidth = 1.6; ctx.setLineDash([5, 6]); ctx.lineDashOffset = -t * 30;
      ctx.beginPath(); ctx.moveTo(hub[0], hub[1]);
      ctx.quadraticCurveTo((hub[0] + x) / 2, Math.min(hub[1], y) - 40, x, y); ctx.stroke();
    });
    ctx.setLineDash([]);
    ctx.restore();
  }
  private advanceHub(): [number, number] {
    const vp = this.viewport();
    return [vp.cx, this.pad.t + 30];
  }

  private drawOverlays(t: number) {
    const ctx = this.ctx;
    const z = this.cam.z;
    const L = this.layer;
    const m = this.model!;
    // Hub Advance
    if (L === 'advance') {
      const [hx, hy] = this.advanceHub();
      ctx.save();
      ctx.shadowColor = 'rgba(230,0,126,0.35)'; ctx.shadowBlur = 18;
      const g = ctx.createLinearGradient(hx - 80, 0, hx + 80, 0); g.addColorStop(0, C.magenta); g.addColorStop(1, C.orange);
      ctx.fillStyle = g; roundRect(ctx, hx - 86, hy - 18, 172, 36, 18); ctx.fill();
      ctx.restore();
      ctx.fillStyle = '#fff'; ctx.font = '600 13px Inter, system-ui, sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillText('Advance · datos integrados', hx, hy + 1);
    }

    // etiquetas de sector
    const placedRects: [number, number, number, number][] = [];
    const ordered = [...this.states.values()].sort((a, b) => (b.x + b.y) - (a.x + a.y));
    ordered.forEach((s) => {
      const a = this.phase(s, 'walls');
      if (a < 0.2) return;
      const ps = s.ps, sec = ps.sector;
      const [x, y0] = this.toScreen(s.x + sec.size.w / 2, s.y + 0.1, Math.max(sec.wallHeight, 1.2) + 0.35);
      let y = y0;
      ctx.globalAlpha = a;
      const full = sec.id === 'expedicion' && !m.flags.logistica ? 'Despacho' : sec.name;
      const label = z < 0.45 && ps.routeIndex !== null ? '' : full;
      const fs = z < 0.55 ? 11 : 12.5;
      ctx.font = `600 ${fs}px Inter, system-ui, sans-serif`;
      const tw = ctx.measureText(label).width;
      const hasNum = ps.routeIndex !== null;
      const bh = fs + 12;
      const bw = label ? tw + 22 + (hasNum ? 22 : 0) : bh + 2;
      const chipOn = L === 'advance' && (ps.modules.length > 0 || ps.id === 'admin');
      const chipTxt = 'Advance · ' + (sec.advanceLabel.split(' · ').slice(1).join(' · ') || sec.advanceLabel);
      ctx.font = '600 11px Inter, system-ui, sans-serif';
      const cw = chipOn ? ctx.measureText(chipTxt).width + 18 : 0;
      const gw = Math.max(bw, cw), gh = bh + (chipOn ? 26 : 0);
      for (let tries = 0; tries < 4; tries++) {
        const r: [number, number, number, number] = [x - gw / 2 - 4, y - bh - 4, gw + 8, gh + 4];
        if (!placedRects.some((q) => r[0] < q[0] + q[2] && r[0] + r[2] > q[0] && r[1] < q[1] + q[3] && r[1] + r[3] > q[1])) break;
        y -= gh + 6;
      }
      placedRects.push([x - gw / 2 - 4, y - bh - 4, gw + 8, gh + 4]);
      ctx.font = `600 ${fs}px Inter, system-ui, sans-serif`;
      const bx = x - bw / 2, by = y - bh - 4;
      const sel = this.selectedSector === ps.id;
      ctx.save();
      ctx.shadowColor = 'rgba(30,40,70,0.16)'; ctx.shadowBlur = 10; ctx.shadowOffsetY = 3;
      ctx.fillStyle = '#ffffff'; roundRect(ctx, bx, by, bw, bh, bh / 2); ctx.fill();
      ctx.restore();
      if (sel) { ctx.strokeStyle = C.magenta; ctx.lineWidth = 1.6; roundRect(ctx, bx, by, bw, bh, bh / 2); ctx.stroke(); }
      if (hasNum) {
        const g = ctx.createLinearGradient(bx, 0, bx + 20, 0); g.addColorStop(0, C.magenta); g.addColorStop(1, C.orange);
        ctx.fillStyle = (L === 'recorrido' || L === 'trazabilidad' || sel) ? g : '#eef0f4';
        ctx.beginPath(); ctx.arc(bx + bh / 2 + 1, by + bh / 2, bh / 2 - 3, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = (L === 'recorrido' || L === 'trazabilidad' || sel) ? '#fff' : '#5b6274';
        ctx.font = `700 ${fs - 2}px Inter, system-ui, sans-serif`; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillText(String(ps.routeIndex! + 1), bx + bh / 2 + 1, by + bh / 2 + 0.5);
      }
      ctx.font = `600 ${fs}px Inter, system-ui, sans-serif`; ctx.fillStyle = '#1d1f27'; ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
      ctx.fillText(label, bx + 11 + (hasNum ? 22 : 0), by + bh / 2 + 0.5);
      this.hits.push({ kind: 'sector', id: ps.id, sectorId: ps.id, sx: x, sy: y, rect: [bx, by, bw, bh] });

      // chip Advance
      if (chipOn) {
        const txt = chipTxt;
        ctx.font = '600 11px Inter, system-ui, sans-serif';
        const g = ctx.createLinearGradient(x - cw / 2, 0, x + cw / 2, 0); g.addColorStop(0, C.magenta); g.addColorStop(1, C.orange);
        ctx.fillStyle = g; roundRect(ctx, x - cw / 2, by + bh + 6, cw, 20, 10); ctx.fill();
        ctx.fillStyle = '#fff'; ctx.textAlign = 'center'; ctx.fillText(txt, x, by + bh + 16.5);
      }
      // badges de trazabilidad
      if (L === 'trazabilidad' && (ps.routeIndex !== null || ps.id === 'abasto')) {
        const [tx, ty0] = this.toScreen(s.x + sec.size.w / 2, s.y + sec.size.d, 0);
        let ty = ty0;
        const lines = [sec.traceLabel, ...ps.modifiers.filter((md) => md.module === 'exportacion').slice(0, 1).map((md) => '⚑ ' + md.text)];
        ctx.font = '600 11px Inter, system-ui, sans-serif';
        const bw2 = Math.max(...lines.map((l) => ctx.measureText(l).width)) + 20;
        const bh2 = 10 + lines.length * 15;
        for (let tries = 0; tries < 4; tries++) {
          const r = [tx - bw2 / 2 - 3, ty + 3, bw2 + 6, bh2 + 6];
          if (!placedRects.some((q) => r[0] < q[0] + q[2] && r[0] + r[2] > q[0] && r[1] < q[1] + q[3] && r[1] + r[3] > q[1])) break;
          ty += bh2 + 6;
        }
        placedRects.push([tx - bw2 / 2 - 3, ty + 3, bw2 + 6, bh2 + 6]);
        ctx.save(); ctx.shadowColor = 'rgba(30,40,70,0.15)'; ctx.shadowBlur = 8;
        ctx.fillStyle = '#fff'; roundRect(ctx, tx - bw2 / 2, ty + 6, bw2, bh2, 8); ctx.fill(); ctx.restore();
        ctx.fillStyle = C.magenta; ctx.fillRect(tx - bw2 / 2, ty + 10, 3, bh2 - 8);
        lines.forEach((l, i) => { ctx.fillStyle = i === 0 ? '#1d1f27' : C.magenta; ctx.textAlign = 'left'; ctx.fillText(l, tx - bw2 / 2 + 10, ty + 6 + 12 + i * 15); });
      }
      ctx.globalAlpha = 1;
    });

    // hotspots de hardware
    const showHot = L === 'headway' || z >= 1.25 || this.selectedSector !== null;
    if (showHot) {
      for (const h of this.hits) {
        if (h.kind !== 'hw') continue;
        const pl = m.hardware.find((x) => x.key === h.id); if (!pl) continue;
        if (L !== 'headway' && this.selectedSector && pl.sectorId !== this.selectedSector && z < 1.25) continue;
        const hw = this.ind.hardware.find((x) => x.id === pl.hwId)!;
        const sel = this.selectedHw === h.id;
        const hov = this.hoverHit?.id === h.id;
        const pulse = (Math.sin(t * 3 + h.sx * 0.05) + 1) / 2;
        ctx.save();
        ctx.fillStyle = `rgba(230,0,126,${0.12 + pulse * 0.12})`;
        ctx.beginPath(); ctx.arc(h.sx, h.sy, 13 + pulse * 3, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = pl.status === 'O' ? '#fff' : C.magenta;
        ctx.strokeStyle = C.magenta; ctx.lineWidth = 2;
        ctx.beginPath(); ctx.arc(h.sx, h.sy, sel || hov ? 9 : 7, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
        ctx.fillStyle = pl.status === 'O' ? C.magenta : '#fff';
        ctx.font = '700 9px Inter, system-ui, sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillText('+', h.sx, h.sy + 0.5);
        if ((L === 'headway' && z >= 0.85) || sel || hov) {
          ctx.font = '600 11px Inter, system-ui, sans-serif';
          const tw = ctx.measureText(hw.code).width + 14;
          ctx.fillStyle = '#1d1f27'; roundRect(ctx, h.sx + 12, h.sy - 9, tw, 18, 9); ctx.fill();
          ctx.fillStyle = '#fff'; ctx.textAlign = 'left'; ctx.fillText(hw.code, h.sx + 19, h.sy + 0.5);
        }
        ctx.restore();
      }
    }
  }
}

function drawForklift(ctx: CanvasRenderingContext2D, x: number, y: number, dir: number, loaded: boolean) {
  box(ctx, x - 0.45, y - 0.35, 0.1, 0.9, 0.7, 0.55, '#ff8a1f');
  box(ctx, x - 0.3, y - 0.3, 0.65, 0.5, 0.6, 0.06, '#2c3038');
  const mx = dir > 0 ? x + 0.45 : x - 0.55;
  box(ctx, mx, y - 0.3, 0, 0.1, 0.6, 1.5, '#4a505c');
  if (loaded) {
    const px = dir > 0 ? x + 0.55 : x - 1.35;
    box(ctx, px, y - 0.4, 0.2, 0.8, 0.8, 0.1, C.wood);
    box(ctx, px + 0.04, y - 0.36, 0.3, 0.72, 0.72, 0.5, C.card);
  }
  const p = iso(x, y, 0.1); ctx.fillStyle = '#23262c'; ctx.beginPath(); ctx.ellipse(p[0], p[1] + 2, 5, 3, 0, 0, Math.PI * 2); ctx.fill();
}

function pip(x: number, y: number, p: [number, number][]) {
  let inside = false;
  for (let i = 0, j = p.length - 1; i < p.length; j = i++) {
    const xi = p[i][0], yi = p[i][1], xj = p[j][0], yj = p[j][1];
    if ((yi > y) !== (yj > y) && x < ((xj - xi) * (y - yi)) / (yj - yi) + xi) inside = !inside;
  }
  return inside;
}

export { ZH };
