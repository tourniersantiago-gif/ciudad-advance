import { iso, box, poly, floorQuad, shade, ZH } from './iso';
import type { FlowItem, HardwareFamily } from '../data/types';

export const C = {
  magenta: '#E6007E', fucsia: '#FF2D87', red: '#FF3B4E', orange: '#FF7A1A',
  steel: '#cfd5dd', steelDark: '#9aa3b0', graphite: '#2c3038', belt: '#4b515d',
  meat: '#c8434b', fat: '#f3d8cf', card: '#d8b07c', wood: '#c9a26c',
  white: '#ffffff', wall: '#fbfbfc', ink: '#1d1f27',
};

// ───────── personas ─────────
const ROLE_COL: Record<string, { body: string; helmet?: string; legs: string }> = {
  plant: { body: '#ffffff', helmet: '#ffffff', legs: '#dfe3ea' },
  logistic: { body: '#344058', helmet: '#ffb347', legs: '#2a2f3a' },
  office: { body: '#7b8db0', legs: '#3c4252' },
  retail: { body: '#ffffff', legs: '#3c4252' },
  tech: { body: '#3f6fb5', helmet: '#ffd23f', legs: '#2a2f3a' },
  customer: { body: '#9aa6bd', legs: '#4a5160' },
};
const SKINS = ['#e9bf9b', '#d39f7c', '#b98563', '#f1cfb2'];
const CUST = ['#d97a7a', '#7aa7d9', '#8fc49a', '#e0b45f', '#a68fd0'];

export function drawPerson(ctx: CanvasRenderingContext2D, x: number, y: number, role: string, t: number, seed: number, device?: string, walking = false) {
  const [px, py] = iso(x, y, 0);
  const c = ROLE_COL[role] ?? ROLE_COL.plant;
  const body = role === 'customer' ? CUST[seed % CUST.length] : c.body;
  const bob = walking ? Math.abs(Math.sin(t * 8 + seed)) * 1.5 : Math.sin(t * 2 + seed) * 0.4;
  // sombra
  ctx.fillStyle = 'rgba(30,35,50,0.14)';
  ctx.beginPath(); ctx.ellipse(px, py, 9, 4.5, 0, 0, Math.PI * 2); ctx.fill();
  // piernas
  const lg = walking ? Math.sin(t * 8 + seed) * 3 : 0;
  ctx.fillStyle = c.legs;
  ctx.fillRect(px - 5, py - 20 - bob, 4, 20 + lg * 0.3);
  ctx.fillRect(px + 1, py - 20 - bob, 4, 20 - lg * 0.3);
  // cuerpo
  ctx.fillStyle = body;
  roundRect(ctx, px - 7.5, py - 43 - bob, 15, 25, 5); ctx.fill();
  ctx.strokeStyle = 'rgba(0,0,0,0.12)'; ctx.lineWidth = 0.8; ctx.stroke();
  if (role === 'plant' || role === 'retail') { // delantal
    ctx.fillStyle = role === 'retail' ? '#b23a48' : '#eef1f5';
    ctx.fillRect(px - 5, py - 34 - bob, 10, 14);
  }
  if (role === 'logistic') { ctx.fillStyle = '#ff9f2e'; ctx.fillRect(px - 7.5, py - 36 - bob, 15, 3); }
  // brazos (trabajando)
  const arm = role === 'customer' || walking ? Math.sin(t * 8 + seed) * 3 : Math.sin(t * 5 + seed) * 4;
  ctx.strokeStyle = shade(body.startsWith('#') ? body : '#888888', -0.15); ctx.lineWidth = 3.2; ctx.lineCap = 'round';
  ctx.beginPath(); ctx.moveTo(px - 7, py - 39 - bob); ctx.lineTo(px - 10, py - 27 - bob + arm); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(px + 7, py - 39 - bob); ctx.lineTo(px + 10, py - 28 - bob - arm * 0.6); ctx.stroke();
  // cabeza
  ctx.fillStyle = SKINS[seed % SKINS.length];
  ctx.beginPath(); ctx.arc(px, py - 50 - bob, 6.2, 0, Math.PI * 2); ctx.fill();
  if (c.helmet) {
    ctx.fillStyle = c.helmet;
    ctx.beginPath(); ctx.arc(px, py - 51.5 - bob, 6.6, Math.PI, 0); ctx.fill();
    ctx.strokeStyle = 'rgba(0,0,0,0.12)'; ctx.lineWidth = 0.6; ctx.stroke();
  } else {
    ctx.fillStyle = '#3b2f2a';
    ctx.beginPath(); ctx.arc(px, py - 52 - bob, 6.2, Math.PI * 1.05, -0.05); ctx.fill();
  }
  // dispositivo en mano
  if (device) {
    const hx = px + 10, hy = py - 30 - bob - arm * 0.6;
    if (device === 'tablet') {
      ctx.fillStyle = C.graphite; roundRect(ctx, hx - 2, hy - 9, 10, 13, 1.5); ctx.fill();
      ctx.fillStyle = C.magenta; ctx.globalAlpha *= 0.85; ctx.fillRect(hx, hy - 7, 6, 9); ctx.globalAlpha /= 0.85;
    } else if (device === 'glove') {
      ctx.fillStyle = '#1f2329'; ctx.beginPath(); ctx.arc(hx, hy, 3.4, 0, Math.PI * 2); ctx.fill();
      if ((t + seed) % 2.2 < 0.25) { ctx.strokeStyle = 'rgba(255,40,60,0.9)'; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.moveTo(hx, hy); ctx.lineTo(hx + 10, hy + 8); ctx.stroke(); }
    } else {
      ctx.fillStyle = '#1f2329'; roundRect(ctx, hx - 2, hy - 8, 6, 11, 1.5); ctx.fill();
      ctx.fillStyle = '#7fd3ff'; ctx.fillRect(hx - 1, hy - 7, 4, 4);
      if ((t + seed) % 2.6 < 0.22) { ctx.strokeStyle = 'rgba(255,40,60,0.9)'; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.moveTo(hx + 1, hy - 8); ctx.lineTo(hx + 12, hy + 4); ctx.stroke(); }
    }
  }
}

export function roundRect(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  ctx.beginPath();
  ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath();
}

// ───────── ganado ─────────
export function drawCattle(ctx: CanvasRenderingContext2D, x: number, y: number, t: number, seed: number, facing = 1) {
  const col = ['#5a4636', '#8a6a4f', '#2f2a28', '#b98d68'][seed % 4];
  const [px, py] = iso(x, y, 0);
  ctx.fillStyle = 'rgba(30,35,50,0.13)';
  ctx.beginPath(); ctx.ellipse(px, py, 14, 6, 0, 0, Math.PI * 2); ctx.fill();
  const b = Math.sin(t * 3 + seed) * 0.6;
  ctx.fillStyle = shade(col, -0.2);
  ctx.fillRect(px - 9, py - 12, 3, 12); ctx.fillRect(px + 6, py - 12, 3, 12);
  ctx.fillStyle = col;
  ctx.beginPath(); ctx.ellipse(px, py - 17 - b, 13, 8, 0, 0, Math.PI * 2); ctx.fill();
  ctx.beginPath(); ctx.ellipse(px + 13 * facing, py - 21 - b + Math.sin(t * 1.3 + seed) * 1.5, 5, 4.5, 0, 0, Math.PI * 2); ctx.fill();
  if (seed % 2) { ctx.fillStyle = '#f2ece4'; ctx.beginPath(); ctx.ellipse(px - 3, py - 18 - b, 4, 3, 0.3, 0, Math.PI * 2); ctx.fill(); }
}

// ───────── camiones ─────────
export function drawTruck(ctx: CanvasRenderingContext2D, x: number, y: number, dir: number, kind: string) {
  // camión orientado sobre eje X; dir = sentido de la cabina
  const L = 3.4, W = 1.1;
  const x0 = x, y0 = y;
  floorQuad(ctx, x0 - 0.1, y0 + 0.1, L + 0.4, W, 0, 'rgba(30,35,50,0.10)');
  const trailer = kind === 'cattle' ? '#d9dde3' : '#ffffff';
  const cabX = dir > 0 ? x0 + L - 0.8 : x0;
  const trX = dir > 0 ? x0 : x0 + 0.85;
  box(ctx, trX, y0, 0.35, L - 0.85, W, 1.25, trailer, { stroke: 'rgba(0,0,0,0.08)' });
  if (kind === 'cattle') {
    for (let i = 0; i < 4; i++) { const a = iso(trX + 0.3 + i * 0.6, y0 + W, 1.0), b = iso(trX + 0.6 + i * 0.6, y0 + W, 1.0); ctx.strokeStyle = '#9aa3b0'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(a[0], a[1]); ctx.lineTo(b[0], b[1]); ctx.stroke(); }
  } else {
    const a = iso(trX + 0.2, y0 + W, 0.95), b = iso(trX + L - 1.05, y0 + W, 0.95);
    ctx.strokeStyle = C.magenta; ctx.lineWidth = 2.2; ctx.beginPath(); ctx.moveTo(a[0], a[1]); ctx.lineTo(b[0], b[1]); ctx.stroke();
  }
  box(ctx, cabX, y0 + 0.05, 0.3, 0.8, W - 0.1, 1.0, '#e9ecf1', { stroke: 'rgba(0,0,0,0.08)' });
  const wx = dir > 0 ? cabX + 0.8 : cabX;
  poly(ctx, [iso(wx, y0 + 0.15, 0.85), iso(wx, y0 + W - 0.15, 0.85), iso(wx, y0 + W - 0.15, 1.2), iso(wx, y0 + 0.15, 1.2)], '#9fc3df');
  for (const wxx of [x0 + 0.5, x0 + L - 0.5]) { const p = iso(wxx, y0 + W, 0.15); ctx.fillStyle = '#2a2d33'; ctx.beginPath(); ctx.ellipse(p[0], p[1], 5, 4, 0, 0, Math.PI * 2); ctx.fill(); }
}

export function drawVan(ctx: CanvasRenderingContext2D, x: number, y: number) {
  floorQuad(ctx, x - 0.6, y - 0.3, 1.4, 0.8, 0, 'rgba(30,35,50,0.12)');
  box(ctx, x - 0.6, y - 0.35, 0.15, 1.2, 0.7, 0.75, '#ffffff', { stroke: 'rgba(0,0,0,0.1)' });
  const a = iso(x - 0.5, y + 0.35, 0.5), b = iso(x + 0.5, y + 0.35, 0.5);
  ctx.strokeStyle = C.magenta; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(a[0], a[1]); ctx.lineTo(b[0], b[1]); ctx.stroke();
}

// ───────── ítems de flujo ─────────
export function drawItem(ctx: CanvasRenderingContext2D, item: FlowItem, x: number, y: number, z: number, t: number, seed: number, kind?: string) {
  if (kind === 'distribution') { drawVan(ctx, x, y); return; }
  switch (item) {
    case 'animal': drawCattle(ctx, x, y, t, seed); break;
    case 'media_res':
    case 'cuarto': {
      if (z < 1.5) { box(ctx, x - 0.25, y - 0.18, z, 0.5, 0.36, 0.16, C.meat, { top: '#d9636b' }); break; }
      const [hx, hy] = iso(x, y, z);
      const len = item === 'media_res' ? 40 : 24;
      const sw = Math.sin(t * 2 + seed) * 1.2;
      ctx.strokeStyle = '#7d8592'; ctx.lineWidth = 1.2;
      ctx.beginPath(); ctx.moveTo(hx, hy); ctx.lineTo(hx + sw, hy + 6); ctx.stroke();
      ctx.fillStyle = C.fat;
      ctx.beginPath(); ctx.ellipse(hx + sw, hy + 6 + len / 2, item === 'media_res' ? 8 : 7, len / 2, 0.05, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = C.meat;
      ctx.beginPath(); ctx.ellipse(hx + sw + 1.5, hy + 6 + len / 2, item === 'media_res' ? 5.5 : 4.5, len / 2 - 2, 0.05, 0, Math.PI * 2); ctx.fill();
      break;
    }
    case 'corte': box(ctx, x - 0.18, y - 0.14, z, 0.36, 0.28, 0.1, C.meat, { top: '#d65c63' }); break;
    case 'envase': box(ctx, x - 0.2, y - 0.16, z, 0.4, 0.32, 0.08, '#f0b9c4', { top: '#f7d3da' }); break;
    case 'producto': box(ctx, x - 0.2, y - 0.2, z, 0.4, 0.4, 0.14, '#e6e9ee', { top: '#f6f7f9' }); break;
    case 'caja': box(ctx, x - 0.22, y - 0.22, z, 0.44, 0.44, 0.3, C.card); break;
    case 'pallet': {
      box(ctx, x - 0.42, y - 0.42, z, 0.84, 0.84, 0.12, C.wood);
      box(ctx, x - 0.38, y - 0.38, z + 0.12, 0.76, 0.76, 0.5, C.card);
      const a = iso(x - 0.38, y + 0.38, z + 0.4), b = iso(x + 0.38, y + 0.38, z + 0.4);
      ctx.fillStyle = '#fff'; ctx.fillRect((a[0] + b[0]) / 2 - 3, (a[1] + b[1]) / 2 - 3, 6, 5);
      break;
    }
    case 'pedido': {
      const [px, py] = iso(x, y, z);
      ctx.fillStyle = C.magenta; roundRect(ctx, px - 7, py - 5, 14, 10, 2); ctx.fill();
      ctx.strokeStyle = '#fff'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(px - 6, py - 4); ctx.lineTo(px, py + 1); ctx.lineTo(px + 6, py - 4); ctx.stroke();
      break;
    }
    default: break;
  }
}

// ───────── hardware ─────────
export function drawHardware(ctx: CanvasRenderingContext2D, fam: HardwareFamily, x: number, y: number, z: number, t: number, seed: number) {
  switch (fam) {
    case 'terminal': {
      box(ctx, x - 0.06, y - 0.06, 0, 0.12, 0.12, 1.05, C.steel);
      box(ctx, x - 0.2, y - 0.2, 0, 0.4, 0.4, 0.05, C.steelDark);
      // pantalla (panel inclinado hacia +y)
      const p1 = iso(x - 0.32, y + 0.05, 1.05), p2 = iso(x + 0.32, y + 0.05, 1.05), p3 = iso(x + 0.32, y + 0.12, 1.55), p4 = iso(x - 0.32, y + 0.12, 1.55);
      poly(ctx, [p1, p2, p3, p4], '#dfe4ea', '#aab2bd', 1);
      const ins = (u: number, v: number) => [p1[0] + (p2[0] - p1[0]) * u + (p4[0] - p1[0]) * v, p1[1] + (p2[1] - p1[1]) * u + (p4[1] - p1[1]) * v] as [number, number];
      poly(ctx, [ins(0.08, 0.1), ins(0.92, 0.1), ins(0.92, 0.9), ins(0.08, 0.9)], '#ffffff');
      poly(ctx, [ins(0.08, 0.72), ins(0.92, 0.72), ins(0.92, 0.9), ins(0.08, 0.9)], C.magenta);
      const row = Math.floor((t * 0.8 + seed) % 3);
      for (let r = 0; r < 3; r++) poly(ctx, [ins(0.14, 0.18 + r * 0.17), ins(0.86, 0.18 + r * 0.17), ins(0.86, 0.28 + r * 0.17), ins(0.14, 0.28 + r * 0.17)], r === row ? '#ffd0e6' : '#e9ecf1');
      break;
    }
    case 'scale': {
      box(ctx, x - 0.35, y - 0.35, 0, 0.7, 0.7, 0.12, C.steel, { top: '#e4e8ed' });
      box(ctx, x + 0.25, y - 0.05, 0, 0.06, 0.06, 0.8, C.steelDark);
      box(ctx, x + 0.12, y - 0.1, 0.8, 0.3, 0.12, 0.2, C.graphite);
      const d = iso(x + 0.27, y + 0.02, 0.9);
      ctx.fillStyle = '#5dffb0'; ctx.fillRect(d[0] - 5, d[1] - 3, 10, 4);
      break;
    }
    case 'rail_scale': {
      const [px, py] = iso(x, y, z);
      ctx.fillStyle = C.graphite; roundRect(ctx, px - 8, py - 16, 16, 10, 2); ctx.fill();
      ctx.fillStyle = '#5dffb0'; ctx.fillRect(px - 5, py - 13, 10, 4);
      ctx.strokeStyle = C.steelDark; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(px, py - 6); ctx.lineTo(px, py); ctx.stroke();
      break;
    }
    case 'scanner': {
      box(ctx, x - 0.04, y - 0.04, 0, 0.08, 0.08, 0.9, C.steelDark);
      const [px, py] = iso(x, y, 0.95);
      ctx.fillStyle = '#23262c'; roundRect(ctx, px - 4, py - 6, 9, 7, 2); ctx.fill();
      ctx.fillRect(px - 1, py, 3, 6);
      if ((t + seed * 0.7) % 2.4 < 0.25) { ctx.strokeStyle = 'rgba(255,40,60,0.85)'; ctx.lineWidth = 1.4; ctx.beginPath(); ctx.moveTo(px + 4, py - 3); ctx.lineTo(px + 16, py + 10); ctx.stroke(); }
      break;
    }
    case 'minipc': {
      box(ctx, x - 0.12, y - 0.1, 0.75, 0.24, 0.2, 0.06, C.graphite);
      break;
    }
    case 'pos':
    case 'smartpos': {
      box(ctx, x - 0.15, y - 0.12, 0.9, 0.3, 0.24, 0.06, C.graphite);
      const p1 = iso(x - 0.2, y, 0.96), p2 = iso(x + 0.2, y, 0.96), p3 = iso(x + 0.2, y + 0.04, 1.3), p4 = iso(x - 0.2, y + 0.04, 1.3);
      poly(ctx, [p1, p2, p3, p4], '#1f2329');
      const m = (a: number[], b: number[], f: number) => [a[0] + (b[0] - a[0]) * f, a[1] + (b[1] - a[1]) * f] as [number, number];
      poly(ctx, [m(p1, p4, 0.12), m(p2, p3, 0.12), m(p2, p3, 0.88), m(p1, p4, 0.88)], (Math.floor(t * 1.2 + seed) % 2) ? '#ffe3f0' : '#ffffff');
      break;
    }
    case 'selfcheckout': {
      box(ctx, x - 0.3, y - 0.25, 0, 0.6, 0.5, 0.9, '#e9ecf1');
      box(ctx, x - 0.25, y - 0.05, 0.9, 0.5, 0.1, 0.55, C.graphite);
      break;
    }
    default: break;
  }
}

// ───────── props ─────────
export function drawRail(ctx: CanvasRenderingContext2D, a: { x: number; y: number }, b: { x: number; y: number }, z: number, posts = true) {
  if (posts) {
    const n = Math.max(1, Math.round(Math.hypot(b.x - a.x, b.y - a.y) / 2.2));
    for (let i = 0; i <= n; i++) {
      const f = i / n; const px = a.x + (b.x - a.x) * f, py = a.y + (b.y - a.y) * f;
      const p0 = iso(px, py - 0.4, 0), p1 = iso(px, py - 0.4, z + 0.25);
      ctx.strokeStyle = '#b9c0ca'; ctx.lineWidth = 2.5; ctx.beginPath(); ctx.moveTo(p0[0], p0[1]); ctx.lineTo(p1[0], p1[1]); ctx.stroke();
      const p2 = iso(px, py, z + 0.25); ctx.beginPath(); ctx.moveTo(p1[0], p1[1]); ctx.lineTo(p2[0], p2[1]); ctx.stroke();
    }
  }
  const A = iso(a.x, a.y, z + 0.08), B = iso(b.x, b.y, z + 0.08);
  ctx.strokeStyle = '#8c95a3'; ctx.lineWidth = 3; ctx.lineCap = 'round';
  ctx.beginPath(); ctx.moveTo(A[0], A[1]); ctx.lineTo(B[0], B[1]); ctx.stroke();
}

export function drawConveyor(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, d: number, t: number, z = 0.66) {
  for (const lx of [x + 0.2, x + w - 0.3]) { box(ctx, lx, y + 0.1, 0, 0.1, 0.1, z, C.steelDark); box(ctx, lx, y + d - 0.2, 0, 0.1, 0.1, z, C.steelDark); }
  box(ctx, x, y, z, w, d, 0.14, C.steel, { top: C.belt });
  // rodillos animados
  const off = (t * 0.8) % 0.5;
  ctx.strokeStyle = 'rgba(255,255,255,0.12)'; ctx.lineWidth = 1;
  for (let i = off; i < w; i += 0.5) { const a = iso(x + i, y, z + 0.14), b = iso(x + i, y + d, z + 0.14); ctx.beginPath(); ctx.moveTo(a[0], a[1]); ctx.lineTo(b[0], b[1]); ctx.stroke(); }
}

export function drawProp(ctx: CanvasRenderingContext2D, type: string, x: number, y: number, w: number, d: number, h: number, v: string | undefined, t: number, seed: number, mirror: boolean) {
  switch (type) {
    case 'pen': {
      floorQuad(ctx, x, y, w, d, 0.01, '#ddd4c2');
      const posts: [number, number][] = [[x, y], [x + w, y], [x + w, y + d], [x, y + d]];
      ctx.strokeStyle = '#a88b66'; ctx.lineWidth = 2;
      for (const hh of [0.35, 0.7]) {
        ctx.beginPath();
        posts.forEach(([px, py], i) => { const p = iso(px, py, hh); if (i === 0) ctx.moveTo(p[0], p[1]); else ctx.lineTo(p[0], p[1]); });
        ctx.closePath(); ctx.stroke();
      }
      posts.forEach(([px, py]) => { const a = iso(px, py, 0), b = iso(px, py, 0.8); ctx.beginPath(); ctx.moveTo(a[0], a[1]); ctx.lineTo(b[0], b[1]); ctx.stroke(); });
      break;
    }
    case 'chute': {
      floorQuad(ctx, x, y, w, d, 0.01, '#e2dacb');
      ctx.strokeStyle = '#a88b66'; ctx.lineWidth = 2;
      for (const yy of [y, y + d]) { const a = iso(x, yy, 0.6), b = iso(x + w, yy, 0.6); ctx.beginPath(); ctx.moveTo(a[0], a[1]); ctx.lineTo(b[0], b[1]); ctx.stroke(); }
      break;
    }
    case 'platform': box(ctx, x, y, 0, w, d, 0.6, '#d7dce3', { top: '#e9edf2' }); break;
    case 'bins': for (let i = 0; i < 2; i++) box(ctx, x + i * 0.6, y, 0, 0.5, 0.5, 0.5, '#4f9bd9'); break;
    case 'tank': box(ctx, x, y, 0, 1.0, 1.0, 1.4, '#e3e7ec'); break;
    case 'saw': box(ctx, x, y, 0, 0.6, 0.6, 1.5, '#e6eaef'); box(ctx, x + 0.1, y + 0.1, 1.5, 0.4, 0.4, 0.3, C.orange); break;
    case 'table': {
      for (const [lx, ly] of [[x + 0.05, y + 0.05], [x + w - 0.15, y + 0.05], [x + 0.05, y + d - 0.15], [x + w - 0.15, y + d - 0.15]]) box(ctx, lx, ly, 0, 0.1, 0.1, 0.75, C.steelDark);
      box(ctx, x, y, 0.75, w, d, 0.08, C.steel, { top: '#eef1f5' });
      box(ctx, x + w * 0.3, y + d * 0.3, 0.83, 0.4, 0.3, 0.08, C.meat);
      break;
    }
    case 'conveyor': drawConveyor(ctx, x, y, w, d, mirror ? -t : t); break;
    case 'machine': {
      const col = v === 'oven' ? '#dfe3e8' : v === 'mixer' ? '#e9edf1' : '#e4e8ed';
      box(ctx, x, y, 0, w, d, h, col);
      box(ctx, x + w * 0.1, y + d - 0.02, h * 0.55, w * 0.35, 0.04, h * 0.25, C.graphite);
      const blink = Math.floor(t * 2 + seed) % 2;
      const p = iso(x + w * 0.8, y + d, h * 0.7);
      ctx.fillStyle = blink ? '#5dffb0' : '#2aa36b'; ctx.beginPath(); ctx.arc(p[0], p[1], 2.2, 0, Math.PI * 2); ctx.fill();
      if (v === 'mixer') { const c = iso(x + w / 2, y + d / 2, h + 0.05); ctx.strokeStyle = C.steelDark; ctx.lineWidth = 2; ctx.beginPath(); ctx.ellipse(c[0], c[1], 14, 7, 0, 0, Math.PI * 2); ctx.stroke(); }
      break;
    }
    case 'printer': {
      box(ctx, x, y, 0, 0.1, 0.1, 0.75, C.steelDark);
      box(ctx, x - 0.2, y - 0.15, 0.75, 0.45, 0.4, 0.3, '#3a3f48');
      const k = (t * 0.5 + seed * 0.3) % 1;
      if (k < 0.6) { const p = iso(x + 0.02, y + 0.25, 0.92 - k * 0.2); ctx.fillStyle = '#fff'; ctx.fillRect(p[0] - 4, p[1] - 3 + k * 6, 8, 5); ctx.fillStyle = C.magenta; ctx.fillRect(p[0] - 4, p[1] - 3 + k * 6, 8, 1.3); }
      break;
    }
    case 'palletStack': box(ctx, x, y, 0, 0.9, 0.9, 0.12, C.wood); box(ctx, x + 0.05, y + 0.05, 0.12, 0.8, 0.8, 0.6, C.card); break;
    case 'pallet': box(ctx, x, y, 0, 0.84, 0.84, 0.12, C.wood); box(ctx, x + 0.04, y + 0.04, 0.12, 0.76, 0.76, 0.45 + (seed % 3) * 0.12, C.card); break;
    case 'rack': {
      const levels = Math.round(h / 0.6);
      for (const lx of [x, x + w - 0.08]) for (const ly of [y, y + d - 0.08]) box(ctx, lx, ly, 0, 0.08, 0.08, h, '#3d6fb6');
      for (let l = 0; l < levels; l++) {
        const zz = l * 0.6 + 0.05;
        box(ctx, x, y, zz, w, d, 0.05, '#f19a3e');
        const n = Math.floor(w / 0.9);
        for (let i = 0; i < n; i++) if ((i + l + seed) % 4 !== 0) box(ctx, x + 0.08 + i * 0.9, y + 0.08, zz + 0.05, 0.72, d - 0.16, 0.42, C.card);
      }
      break;
    }
    case 'pickPath': {
      ctx.setLineDash([6, 6]); ctx.lineDashOffset = -t * 20;
      const a = iso(x, y + d / 2, 0.02), b = iso(x + w, y + d / 2, 0.02);
      ctx.strokeStyle = C.orange; ctx.lineWidth = 2.5; ctx.beginPath(); ctx.moveTo(a[0], a[1]); ctx.lineTo(b[0], b[1]); ctx.stroke(); ctx.setLineDash([]);
      break;
    }
    case 'coldDoor': {
      const open = (Math.sin(t * 0.6 + seed) + 1) / 2;
      const len = d * (1 - open * 0.85);
      box(ctx, x, y + d - len, 0, 0.12, len, 2.0, '#cfe0ee', { top: '#e6f0f8' });
      break;
    }
    case 'dock': box(ctx, x, y, 0, w, d, 0.5, '#c4cad3'); poly(ctx, [iso(x + w, y, 0.5), iso(x + w, y + d, 0.5), iso(x + w, y + d, 1.6), iso(x + w, y, 1.6)], 'rgba(60,70,90,0.25)'); break;
    case 'exportStaging': {
      floorQuad(ctx, x, y, w, d, 0.02, 'rgba(230,0,126,0.08)', 'rgba(230,0,126,0.55)');
      for (let i = 0; i < 2; i++) { box(ctx, x + 0.3 + i * 1.2, y + 0.2, 0, 0.84, 0.84, 0.12, C.wood); box(ctx, x + 0.34 + i * 1.2, y + 0.24, 0.12, 0.76, 0.76, 0.55, '#e7c592'); }
      const f = iso(x + w - 0.2, y + 0.2, 0); const f2 = iso(x + w - 0.2, y + 0.2, 1.4);
      ctx.strokeStyle = '#6b7380'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(f[0], f[1]); ctx.lineTo(f2[0], f2[1]); ctx.stroke();
      ctx.fillStyle = C.magenta; ctx.beginPath(); ctx.moveTo(f2[0], f2[1]); ctx.lineTo(f2[0] + 14 + Math.sin(t * 3) * 1.5, f2[1] + 4); ctx.lineTo(f2[0], f2[1] + 9); ctx.fill();
      break;
    }
    case 'desk': {
      box(ctx, x, y, 0, 1.2, 0.6, 0.72, '#e8dccb', { top: '#f3ebe0' });
      box(ctx, x + 0.35, y + 0.08, 0.72, 0.5, 0.06, 0.35, '#2b2f36');
      const p = iso(x + 0.6, y + 0.15, 0.92); ctx.fillStyle = (Math.floor(t + seed) % 3) ? '#dfe9ff' : '#ffe1ef'; ctx.fillRect(p[0] - 7, p[1] - 6, 14, 8);
      break;
    }
    case 'meeting': box(ctx, x, y, 0, w, d, 0.7, '#e8dccb', { top: '#f3ebe0' }); break;
    case 'bigscreen': {
      box(ctx, x, y, 0, 0.1, 0.1, 1.0, C.steelDark);
      const p1 = iso(x - 0.9, y + 0.1, 1.0), p2 = iso(x + 1.0, y + 0.1, 1.0), p3 = iso(x + 1.0, y + 0.1, 2.0), p4 = iso(x - 0.9, y + 0.1, 2.0);
      poly(ctx, [p1, p2, p3, p4], '#1f2329');
      const m = (a: number[], b: number[], f: number) => [a[0] + (b[0] - a[0]) * f, a[1] + (b[1] - a[1]) * f];
      for (let i = 0; i < 5; i++) {
        const hh = 0.25 + 0.55 * ((Math.sin(t * 0.8 + i * 1.7) + 1) / 2);
        const u0 = 0.12 + i * 0.16, u1 = u0 + 0.1;
        const b0 = m(p1, p2, u0), b1 = m(p1, p2, u1);
        const dz = (p4[1] - p1[1]) * hh * 0.85;
        poly(ctx, [[b0[0], b0[1] - 4], [b1[0], b1[1] - 4], [b1[0], b1[1] - 4 + dz], [b0[0], b0[1] - 4 + dz]], i % 2 ? C.orange : C.magenta);
      }
      break;
    }
    case 'plant': box(ctx, x, y, 0, 0.4, 0.4, 0.4, '#d9d1c4'); { const p = iso(x + 0.2, y + 0.2, 0.75); ctx.fillStyle = '#6aa874'; ctx.beginPath(); ctx.arc(p[0], p[1], 10, 0, Math.PI * 2); ctx.fill(); } break;
    case 'fridge': {
      box(ctx, x, y, 0, w, d, 0.85, '#f0f2f5');
      poly(ctx, [iso(x, y + d, 0.85), iso(x + w, y + d, 0.85), iso(x + w, y + d - 0.3, 1.2), iso(x, y + d - 0.3, 1.2)], 'rgba(170,210,235,0.55)', '#aab2bd');
      for (let i = 0; i < 6; i++) box(ctx, x + 0.2 + i * 0.5, y + 0.2, 0.85, 0.35, 0.3, 0.06, i % 2 ? C.meat : '#d55a62');
      break;
    }
    case 'shelf': box(ctx, x, y, 0, w, d, 1.4, '#e9e2d8'); break;
    case 'cashier': box(ctx, x, y, 0, w, d, 0.9, '#e8dccb', { top: '#f4ede3' }); break;
    case 'portal': {
      const [px, py] = iso(x, y, 0);
      ctx.fillStyle = 'rgba(230,0,126,0.10)'; ctx.beginPath(); ctx.ellipse(px, py, 70, 35, 0, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = 'rgba(230,0,126,0.5)'; ctx.lineWidth = 1.5; ctx.setLineDash([4, 5]); ctx.lineDashOffset = -t * 10; ctx.stroke(); ctx.setLineDash([]);
      const fl = Math.sin(t * 1.5) * 4;
      // laptop
      ctx.fillStyle = '#2b2f36'; roundRect(ctx, px - 46, py - 70 + fl, 44, 30, 3); ctx.fill();
      ctx.fillStyle = '#fff'; ctx.fillRect(px - 43, py - 67 + fl, 38, 24);
      ctx.fillStyle = C.magenta; ctx.fillRect(px - 43, py - 67 + fl, 38, 5);
      ctx.fillStyle = '#e9ecf1'; for (let i = 0; i < 3; i++) ctx.fillRect(px - 40 + i * 12, py - 58 + fl, 9, 9);
      // teléfono
      ctx.fillStyle = '#2b2f36'; roundRect(ctx, px + 12, py - 80 - fl, 20, 36, 4); ctx.fill();
      ctx.fillStyle = '#fff'; ctx.fillRect(px + 14, py - 76 - fl, 16, 28);
      ctx.fillStyle = C.orange; ctx.fillRect(px + 14, py - 76 - fl, 16, 4);
      ctx.fillStyle = '#ffd0e6'; ctx.fillRect(px + 16, py - 68 - fl, 12, 8);
      break;
    }
    case 'workbench': box(ctx, x, y, 0, w, d, 0.8, '#7a8696', { top: '#9aa6b5' }); break;
    case 'selfcheckoutKiosk': break; // lo dibuja el hardware AC01
    default: break;
  }
}

export { ZH };
