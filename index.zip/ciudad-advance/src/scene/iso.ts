// Primitivas isométricas (Canvas 2D). 1 tile = 64×32 px, 1 unidad de altura = 34 px.
export const TW2 = 32;
export const TH2 = 16;
export const ZH = 34;

export function iso(x: number, y: number, z = 0): [number, number] {
  return [(x - y) * TW2, (x + y) * TH2 - z * ZH];
}

const shadeCache = new Map<string, string>();
export function shade(hex: string, amt: number): string {
  const key = hex + amt;
  const c = shadeCache.get(key);
  if (c) return c;
  const n = parseInt(hex.slice(1), 16);
  let r = (n >> 16) & 255, g = (n >> 8) & 255, b = n & 255;
  if (amt < 0) { r *= 1 + amt; g *= 1 + amt; b *= 1 + amt; }
  else { r += (255 - r) * amt; g += (255 - g) * amt; b += (255 - b) * amt; }
  const out = `rgb(${r | 0},${g | 0},${b | 0})`;
  shadeCache.set(key, out);
  return out;
}

export function poly(ctx: CanvasRenderingContext2D, pts: [number, number][], fill?: string, stroke?: string, lw = 1) {
  ctx.beginPath();
  ctx.moveTo(pts[0][0], pts[0][1]);
  for (let i = 1; i < pts.length; i++) ctx.lineTo(pts[i][0], pts[i][1]);
  ctx.closePath();
  if (fill) { ctx.fillStyle = fill; ctx.fill(); }
  if (stroke) { ctx.strokeStyle = stroke; ctx.lineWidth = lw; ctx.stroke(); }
}

/** caja isométrica: caras superior, +y (izquierda) y +x (derecha) */
export function box(ctx: CanvasRenderingContext2D, x: number, y: number, z: number, w: number, d: number, h: number, color: string, opts?: { top?: string; left?: string; right?: string; stroke?: string }) {
  const t1 = iso(x, y, z + h), t2 = iso(x + w, y, z + h), t3 = iso(x + w, y + d, z + h), t4 = iso(x, y + d, z + h);
  const b2 = iso(x + w, y, z), b3 = iso(x + w, y + d, z), b4 = iso(x, y + d, z);
  const st = opts?.stroke;
  poly(ctx, [b4, b3, t3, t4], opts?.left ?? shade(color, -0.1), st, 0.6);
  poly(ctx, [b2, b3, t3, t2], opts?.right ?? shade(color, -0.2), st, 0.6);
  poly(ctx, [t1, t2, t3, t4], opts?.top ?? color, st, 0.6);
}

export function floorQuad(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, d: number, z: number, fill: string, stroke?: string) {
  poly(ctx, [iso(x, y, z), iso(x + w, y, z), iso(x + w, y + d, z), iso(x, y + d, z)], fill, stroke);
}

export function line3(ctx: CanvasRenderingContext2D, pts: { x: number; y: number; z: number }[], color: string, w: number, dash?: number[], offset = 0) {
  if (pts.length < 2) return;
  ctx.beginPath();
  const p0 = iso(pts[0].x, pts[0].y, pts[0].z);
  ctx.moveTo(p0[0], p0[1]);
  for (let i = 1; i < pts.length; i++) { const p = iso(pts[i].x, pts[i].y, pts[i].z); ctx.lineTo(p[0], p[1]); }
  ctx.strokeStyle = color; ctx.lineWidth = w; ctx.lineCap = 'round'; ctx.lineJoin = 'round';
  if (dash) { ctx.setLineDash(dash); ctx.lineDashOffset = offset; }
  ctx.stroke();
  if (dash) ctx.setLineDash([]);
}

export const easeInOut = (t: number) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2);
export const easeOut = (t: number) => 1 - Math.pow(1 - t, 3);
export const clamp01 = (v: number) => (v < 0 ? 0 : v > 1 ? 1 : v);

/** Polilínea con longitudes acumuladas para muestreo */
export interface Poly3 { pts: { x: number; y: number; z: number }[]; cum: number[]; len: number }
export function mkPoly(pts: { x: number; y: number; z: number }[]): Poly3 {
  const cum = [0];
  for (let i = 1; i < pts.length; i++) {
    const a = pts[i - 1], b = pts[i];
    cum.push(cum[i - 1] + Math.hypot(b.x - a.x, b.y - a.y, (b.z - a.z) * 0.3));
  }
  return { pts, cum, len: cum[cum.length - 1] };
}
export function samplePoly(p: Poly3, s: number) {
  const { pts, cum } = p;
  if (pts.length === 1 || p.len === 0) return { ...pts[0], dx: 1, dy: 0 };
  let i = 1;
  while (i < cum.length - 1 && cum[i] < s) i++;
  const a = pts[i - 1], b = pts[i];
  const segL = cum[i] - cum[i - 1] || 1;
  const f = clamp01((s - cum[i - 1]) / segL);
  return { x: a.x + (b.x - a.x) * f, y: a.y + (b.y - a.y) * f, z: a.z + (b.z - a.z) * f, dx: b.x - a.x, dy: b.y - a.y };
}
