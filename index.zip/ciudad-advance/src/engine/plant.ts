// Motor puro: módulos activos → reglas → sectores → recorrido → layout → hardware.
// No depende de React ni del renderer: se puede testear y reutilizar por industria.
import type { Industry, Sector, HwStatus, FlowItem, AnchorType, AdvanceModule } from '../data/types';
import { familyAnchor } from '../data/frigorifico/hardware';
import { sectorOverrides } from '../data/frigorifico';
import { BACKOFFICE_MODULES } from '../data/frigorifico/modules';

export interface Notice {
  id: string;
  level: 'info' | 'warn' | 'auto';
  text: string;
  action?: { label: string; add?: string[]; remove?: string[] };
}

export interface P3 { x: number; y: number; z: number }

export interface PlacedSector {
  id: string;
  sector: Sector;
  gx: number; gy: number;
  mirror: boolean;
  routeIndex: number | null;
  modules: string[];
  modifiers: { module: string; text: string }[];
}

export interface HwPlacement {
  key: string;
  hwId: string;
  sectorId: string;
  status: HwStatus;
  anchor: AnchorType;
  pos: P3 | null; // null = compatible pero no ubicado visualmente (slot ocupado)
  operatorIndex?: number;
  task: string;
}

export interface PathSeg { pts: P3[]; item: FlowItem; kind: 'inside' | 'corridor' | 'distribution' | 'branch' | 'order' }

export interface RouteStep { sectorId: string; label: string; sub?: string }

export interface PlantModel {
  active: string[];
  autoAdded: string[];
  notices: Notice[];
  flags: Record<string, boolean>;
  sectors: PlacedSector[];
  steps: RouteStep[];
  routeSegs: PathSeg[];
  branchSegs: PathSeg[];
  edgesWarn: string[];
  hardware: HwPlacement[];
  bounds: { minX: number; minY: number; maxX: number; maxY: number };
  solutions: string[];
}

const PHYSICAL = ['faena', 'cuarteo', 'desposte', 'empaque_primario', 'empaque_secundario', 'produccion'];
const PER_ROW_MAX = 5;
const GAP = 2;
const ROW_GAP = 4;

const rank: Record<HwStatus, number> = { P: 0, PO: 1, O: 2, NA: 9 };

export function buildPlant(ind: Industry, activeIn: string[], showOptional: boolean): PlantModel {
  const notices: Notice[] = [];
  const autoAdded: string[] = [];
  const act = new Set(activeIn.filter((id) => ind.modules.some((m) => m.id === id)));
  const mod = (id: string) => ind.modules.find((m) => m.id === id) as AdvanceModule;
  const has = (id: string) => act.has(id);

  // ─────────── 1. Reglas de dependencia ───────────
  if (has('wms') && !has('deposito')) {
    act.add('deposito'); autoAdded.push('deposito');
    notices.push({ id: 'wms-dep', level: 'auto', text: 'WMS es una capa avanzada sobre el depósito: se incorporó Depósito / Cámaras.' });
  }
  const needsBO = [...act].filter((id) => mod(id).requires?.includes('backoffice'));
  const hasBO = [...act].some((id) => BACKOFFICE_MODULES.includes(id));
  const backOffice = hasBO || needsBO.length > 0;
  if (needsBO.length && !hasBO) {
    notices.push({ id: 'bo', level: 'auto', text: `${needsBO.map((i) => mod(i).name).join(', ')} requiere Back Office: se muestra el edificio de Administración (Back Office).` });
  }
  const anyPhysical = PHYSICAL.some(has);
  if (has('exportacion') && !anyPhysical) {
    notices.push({ id: 'exp-alone', level: 'warn', text: 'Exportación es una regla sobre procesos: activá al menos un proceso (Faena, Cuarteo, Desposte o Empaque).' });
  }
  if (has('faena') && has('desposte') && !has('cuarteo')) {
    notices.push({ id: 'cuarteo-sug', level: 'warn', text: 'Faena + Desposte sin Cuarteo: ¿las medias reses ingresan directo a Desposte? Según el modelo operativo puede requerirse Cuarteo.', action: { label: 'Agregar Cuarteo', add: ['cuarteo'] } });
  }
  if (has('empaque_secundario') && !has('empaque_primario')) {
    notices.push({ id: 'emp2', level: 'info', text: 'Empaque secundario sin primario: el recorrido asume producto ya envasado.' });
  }
  if ((has('ecommerce') || has('b2b')) && !has('deposito') && !has('logistica')) {
    notices.push({ id: 'dig', level: 'warn', text: 'Los canales digitales generan pedidos que se preparan en Depósito y salen por Logística.', action: { label: 'Agregar Depósito + Logística', add: ['deposito', 'logistica'] } });
  }
  if (has('abasto') && !['faena', 'cuarteo', 'desposte'].some(has)) {
    notices.push({ id: 'abasto-ind', level: 'info', text: 'Abasto opera como circuito independiente de recepción, repesaje y despacho.' });
  }
  if (has('exportacion') && anyPhysical) {
    notices.push({ id: 'exp-layer', level: 'info', text: 'Exportación no crea una sala: modifica etiquetado, trazabilidad, empaque, depósito y suma staging en expedición.' });
  }

  // ─────────── 2. Sectores ───────────
  const sectorIds = new Set<string>();
  act.forEach((id) => mod(id).sectors.forEach((s) => sectorIds.add(s)));
  if (!has('faena')) sectorIds.delete('hacienda');
  const mainPhysical = ind.sectors.filter((s) => s.lane === 'main' && sectorIds.has(s.id) && !['hacienda', 'expedicion'].includes(s.id));
  const chain = mainPhysical.length > 0 || has('faena');
  if (chain && !has('faena')) sectorIds.add('recepcion');
  if (chain) sectorIds.add('expedicion');
  if (backOffice || [...act].some((id) => mod(id).category === 'management')) sectorIds.add('admin');

  const main = ind.sectors.filter((s) => s.lane === 'main' && sectorIds.has(s.id)).sort((a, b) => a.order - b.order);

  // ─────────── 3. Recorrido (pasos) ───────────
  const steps: RouteStep[] = main.map((s) => {
    if (s.id === 'recepcion') {
      const first = main.find((m) => m.id !== 'recepcion');
      return { sectorId: s.id, label: 'Recepción', sub: first ? ind.receptionItems[first.id] : undefined };
    }
    if (s.id === 'expedicion' && !has('logistica')) return { sectorId: s.id, label: 'Despacho', sub: 'sin módulo Logística' };
    return { sectorId: s.id, label: s.name };
  });
  const retailInRoute = sectorIds.has('retail') && chain;
  if (retailInRoute) steps.push({ sectorId: 'retail', label: 'Carnicerías / POS', sub: 'distribución' });

  // compatibilidad de conexiones
  const edgesWarn: string[] = [];
  const outputsOf = (sid: string): string[] => {
    if (sid === 'hacienda') return ['faena'];
    if (sid === 'recepcion') return ind.sectors.map((s) => s.id);
    if (sid === 'expedicion') return ['retail'];
    const m = ind.modules.find((mm) => mm.sectors.includes(sid));
    return m ? m.outputs : [];
  };
  for (let i = 0; i < main.length - 1; i++) {
    const a = main[i].id, b = main[i + 1].id;
    const outs = outputsOf(a);
    const ok = outs.includes(b) || (b === 'expedicion' && outs.includes('deposito')) || (b === 'expedicion');
    if (!ok) {
      edgesWarn.push(`${a}>${b}`);
      if (!(a === 'faena' && b === 'desposte')) {
        notices.push({ id: `edge-${a}-${b}`, level: 'warn', text: `Conexión no estándar: ${main[i].name} → ${main[i + 1].name}. Validar el modelo operativo.` });
      }
    }
  }

  // ─────────── 4. Layout ───────────
  const placed: PlacedSector[] = [];
  const total = main.length;
  const perRow = total <= PER_ROW_MAX ? total : Math.ceil(total / 2);
  let y = 0;
  let row0Right = 0;
  for (let r = 0; r * perRow < total; r++) {
    const rowItems = main.slice(r * perRow, (r + 1) * perRow);
    const depth = Math.max(...rowItems.map((s) => s.size.d));
    const reverse = r % 2 === 1;
    if (!reverse) {
      let x = 0;
      rowItems.forEach((s) => { placed.push(mk(s, x, y, false)); x += s.size.w + GAP; });
      row0Right = Math.max(row0Right, x - GAP);
    } else {
      let x = row0Right;
      rowItems.forEach((s) => { x -= s.size.w; placed.push(mk(s, x, y, true)); x -= GAP; });
    }
    y += depth + ROW_GAP;
  }
  const frontY = total ? y : 0;

  // ramas (detrás de la fila 0)
  const sAbasto = ind.sectors.find((s) => s.id === 'abasto')!;
  if (sectorIds.has('abasto')) {
    const linked = placed.filter((p) => ['faena', 'cuarteo', 'desposte'].includes(p.id) && p.gy === 0);
    const cx = linked.length ? linked.reduce((acc, p) => acc + p.gx + p.sector.size.w / 2, 0) / linked.length : 2;
    placed.push(mk(sAbasto, Math.round(cx - sAbasto.size.w / 2), -(sAbasto.size.d + ROW_GAP), false));
  }
  if (sectorIds.has('taller')) {
    const sT = ind.sectors.find((s) => s.id === 'taller')!;
    const busy = placed.find((p) => p.id === 'abasto');
    let tx = Math.max(row0Right - sT.size.w, 0);
    if (busy && tx < busy.gx + busy.sector.size.w + 2) tx = busy.gx + busy.sector.size.w + 2;
    placed.push(mk(sT, tx, -(sT.size.d + ROW_GAP), false));
  }
  // satélites (frente)
  let sx = 0;
  ['admin', 'digital', 'retail'].forEach((id) => {
    if (!sectorIds.has(id)) return;
    const s = ind.sectors.find((ss) => ss.id === id)!;
    placed.push(mk(s, sx, frontY, false));
    sx += s.size.w + 3;
  });

  function mk(s: Sector, gx: number, gy: number, mirror: boolean): PlacedSector {
    const mods = ind.modules.filter((m) => act.has(m.id) && (m.sectors.includes(s.id) || (m.modifies && m.modifies[s.id]))).map((m) => m.id);
    const modifiers: { module: string; text: string }[] = [];
    act.forEach((mid) => { const m = mod(mid); m.modifies?.[s.id]?.forEach((t) => modifiers.push({ module: mid, text: t })); });
    return { id: s.id, sector: s, gx, gy, mirror, routeIndex: null, modules: mods, modifiers };
  }
  steps.forEach((st, i) => { const p = placed.find((pp) => pp.id === st.sectorId); if (p) p.routeIndex = i; });

  // ─────────── 5. Trayectorias ───────────
  const toWorld = (p: PlacedSector, lx: number, ly: number, z = 0): P3 => ({
    x: p.gx + (p.mirror ? p.sector.size.w - lx : lx), y: p.gy + ly, z,
  });
  const dirOf = (p: PlacedSector) => (p.mirror ? -1 : 1);
  const routeSegs: PathSeg[] = [];
  const mainPlaced = steps.map((st) => placed.find((p) => p.id === st.sectorId)!).filter((p) => p && p.sector.lane === 'main');
  let prevItem: FlowItem | null = null;
  mainPlaced.forEach((p, i) => {
    const s = p.sector;
    const pts = s.flowPath.map(([lx, ly]) => toWorld(p, lx, ly, s.flowZ));
    if (pts.length >= 2) {
      const a = pts[0], b = pts[pts.length - 1];
      const mid = { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2, z: s.flowZ };
      routeSegs.push({ pts: [a, mid], item: prevItem ?? s.outItem, kind: 'inside' });
      routeSegs.push({ pts: [mid, b], item: s.outItem, kind: 'inside' });
    }
    prevItem = s.outItem;
    const next = mainPlaced[i + 1];
    if (next && pts.length) {
      const ex = pts[pts.length - 1];
      const nPts = next.sector.flowPath.map(([lx, ly]) => toWorld(next, lx, ly, next.sector.flowZ));
      const en = nPts[0];
      routeSegs.push({ pts: corridor(ex, dirOf(p), en, dirOf(next)), item: s.outItem, kind: 'corridor' });
    }
  });
  const pRetail = placed.find((p) => p.id === 'retail');
  const pExp = placed.find((p) => p.id === 'expedicion');
  if (retailInRoute && pRetail && pExp) {
    const a = toWorld(pExp, pExp.sector.size.w + 3.5, 3, 0);
    const b = toWorld(pRetail, pRetail.sector.size.w / 2, pRetail.sector.size.d + 1.2, 0);
    routeSegs.push({ pts: [a, { x: a.x, y: b.y, z: 0 }, b], item: 'pallet', kind: 'distribution' });
  }

  const branchSegs: PathSeg[] = [];
  const pAb = placed.find((p) => p.id === 'abasto');
  if (pAb) {
    const abIn = toWorld(pAb, pAb.sector.size.w / 2, pAb.sector.size.d, 0);
    placed.filter((p) => ['faena', 'cuarteo', 'desposte'].includes(p.id)).forEach((p) => {
      const c = toWorld(p, p.sector.size.w / 2, 0.2, 0);
      const midY = (c.y + abIn.y) / 2;
      branchSegs.push({ pts: [c, { x: c.x, y: midY, z: 0 }, { x: abIn.x, y: midY, z: 0 }, abIn], item: 'caja', kind: 'branch' });
    });
    if (pExp) {
      const abOut = toWorld(pAb, pAb.sector.size.w, pAb.sector.size.d / 2, 0);
      const e = toWorld(pExp, pExp.sector.size.w / 2, 0.2, 0);
      const ox = Math.max(abOut.x + 1, 0);
      branchSegs.push({ pts: [abOut, { x: ox, y: abOut.y, z: 0 }, { x: ox, y: e.y - 1.2, z: 0 }, { x: e.x, y: e.y - 1.2, z: 0 }, e], item: 'pallet', kind: 'branch' });
    }
  }
  const pDig = placed.find((p) => p.id === 'digital');
  const pDep = placed.find((p) => p.id === 'deposito') ?? pExp;
  if (pDig && pDep) {
    const a = toWorld(pDig, 2, 2, 1.6);
    const b = toWorld(pDep, pDep.sector.size.w / 2, pDep.sector.size.d / 2, 2.6);
    branchSegs.push({ pts: [a, { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2, z: 6 }, b], item: 'pedido', kind: 'order' });
  }

  // ─────────── 6. Hardware ───────────
  const hwOut: HwPlacement[] = [];
  placed.forEach((p) => {
    const col = ind.matrixColumns.find((c) => c.sectors.includes(p.id));
    const used: Record<string, number> = {};
    const opsUsed = new Set<number>();
    const candidates = ind.matrix
      .map((r) => {
        let st: HwStatus = sectorOverrides[p.id]?.[r.hardwareId] ?? (col ? r.status[col.id] : 'NA');
        if (sectorOverrides[p.id] && !(r.hardwareId in sectorOverrides[p.id])) st = 'NA';
        if (p.id === 'expedicion' && has('exportacion') && r.hardwareId === 'CDAR6') st = 'P';
        if (p.id === 'deposito' && r.hardwareId === 'LCBGP' && !has('wms')) st = 'O';
        if (p.id === 'taller' && !has('mantenimiento')) st = 'NA';
        return { hwId: r.hardwareId, st };
      })
      .filter((c) => c.st !== 'NA')
      .sort((a, b) => rank[a.st] - rank[b.st]);
    candidates.forEach(({ hwId, st }) => {
      const hw = ind.hardware.find((h) => h.id === hwId)!;
      const visible = st !== 'O' || showOptional;
      const anchor = familyAnchor[hw.family];
      const task = ind.tasks[hw.family]?.[p.id] ?? ind.tasks[hw.family]?.['*'] ?? '';
      let pos: P3 | null = null;
      let operatorIndex: number | undefined;
      if (visible) {
        if (anchor === 'operator') {
          const idx = p.sector.operators.findIndex((o, i) => !opsUsed.has(i) && o.role !== 'office' && o.role !== 'retail');
          if (idx >= 0) {
            opsUsed.add(idx); operatorIndex = idx;
            const o = p.sector.operators[idx];
            pos = toWorld(p, o.x, o.y, 1.1);
          }
        } else {
          const slots = p.sector.anchors[anchor] ?? [];
          const n = used[anchor] ?? 0;
          if (n < slots.length) {
            used[anchor] = n + 1;
            const [lx, ly] = slots[n];
            pos = toWorld(p, lx, ly, anchor === 'railscale' ? 2.1 : 0);
          }
        }
      }
      hwOut.push({ key: `${p.id}:${hwId}`, hwId, sectorId: p.id, status: st, anchor, pos, operatorIndex, task });
    });
  });

  // ─────────── 7. Bounds + soluciones ───────────
  const bounds = { minX: 0, minY: 0, maxX: 10, maxY: 10 };
  if (placed.length) {
    bounds.minX = Math.min(...placed.map((p) => p.gx)) - 5;
    bounds.minY = Math.min(...placed.map((p) => p.gy)) - 4;
    bounds.maxX = Math.max(...placed.map((p) => p.gx + p.sector.size.w)) + 6;
    bounds.maxY = Math.max(...placed.map((p) => p.gy + p.sector.size.d)) + 4;
  }

  const solutions: string[] = [];
  const suiteActive = (suite: string) => [...act].some((id) => mod(id).suite === suite);
  if (suiteActive('Advance Frigorífico')) solutions.push('Advance Frigorífico');
  if (backOffice) solutions.push('Advance ERP · Back Office');
  ['wms', 'produccion', 'pos', 'ecommerce', 'b2b', 'crm', 'rrhh', 'mantenimiento', 'proyectos', 'assistant', 'ia'].forEach((id) => { if (has(id)) solutions.push(mod(id).name); });

  const flags: Record<string, boolean> = { backOffice };
  act.forEach((id) => { flags[id] = true; });
  hwOut.forEach((h) => { if (h.pos) flags[`hw:${h.hwId}`] = true; });

  return { active: [...act], autoAdded, notices, flags, sectors: placed, steps, routeSegs, branchSegs, edgesWarn, hardware: hwOut, bounds, solutions };
}

function corridor(a: P3, dirA: number, b: P3, dirB: number): P3[] {
  // altura constante del pasillo: riel si ambos lados son riel, cinta si alguno es cinta, piso si no
  const zm = a.z > 1.5 && b.z > 1.5 ? 2.1 : a.z > 0.3 || b.z > 0.3 ? 0.8 : 0;
  const A = { ...a, z: zm }, B = { ...b, z: zm };
  if (Math.abs(a.y - b.y) < 0.01) return [A, B];
  const xx = dirA > 0 ? Math.max(a.x, b.x) + 1 : Math.min(a.x, b.x) - 1;
  return [A, { x: xx, y: a.y, z: zm }, { x: xx, y: b.y, z: zm }, B];
}
