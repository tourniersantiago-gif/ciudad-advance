import { useEffect, useMemo, useRef, useState } from 'react';
import { useStore, sceneApi } from './store';
import { buildPlant } from './engine/plant';
import { PlantRenderer } from './scene/renderer';
import { IND } from './ui/helpers';
import { ConfigPanel } from './ui/ConfigPanel';
import { SectorSheet, HardwareSheet } from './ui/Sheets';
import { TopBar, Timeline, Summary, MatrixModal, Intro, PresetPicker, RoutePreview, BuildToast, Logo } from './ui/Chrome';

const DEMO = IND.presets.find((p) => p.id === 'integral')!.modules;

function useIsMobile() {
  const [m, setM] = useState(() => window.innerWidth < 860);
  useEffect(() => { const f = () => setM(window.innerWidth < 860); window.addEventListener('resize', f); return () => window.removeEventListener('resize', f); }, []);
  return m;
}

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const st = useStore();
  const { stage, active, showOptional, layer, selectedSector, selectedHw, drawerOpen, summaryOpen, matrixOpen } = st;
  const mobile = useIsMobile();
  const model = useMemo(() => buildPlant(IND, active, showOptional), [active, showOptional]);
  const built = useRef(false);

  // escena
  useEffect(() => {
    const c = canvasRef.current!;
    const r = new PlantRenderer(c, IND, {
      onSelectSector: (id) => { useStore.getState().selectSector(id); if (id) r.focusSector(id); if (window.innerWidth < 860) useStore.getState().setDrawer(false); },
      onSelectHardware: (key) => useStore.getState().selectHw(key),
      onBuildPhase: (p) => useStore.getState().setBuildPhase(p),
    });
    sceneApi.r = r;
    const ro = new ResizeObserver(() => r.resize());
    ro.observe(c);
    r.setModel(buildPlant(IND, DEMO, false), 'silent');
    return () => { ro.disconnect(); r.destroy(); sceneApi.r = null; };
  }, []);

  // padding de cámara según la UI visible
  useEffect(() => {
    const r = sceneApi.r; if (!r) return;
    if (mobile) r.setPadding({ l: 0, r: 0, t: 64, b: selectedSector ? window.innerHeight * 0.48 : 96 });
    else r.setPadding({ l: stage === 'plant' ? 360 : 0, r: selectedSector ? 420 : summaryOpen ? 330 : 24, t: 72, b: 100 });
    if (stage === 'plant' && !selectedSector) r.fitAll(true);
  }, [mobile, stage, selectedSector, summaryOpen]);

  // sincronizar estado → renderer
  useEffect(() => { if (sceneApi.r) { sceneApi.r.layer = layer; } }, [layer]);
  useEffect(() => { if (sceneApi.r) { sceneApi.r.selectedSector = selectedSector; } }, [selectedSector]);
  useEffect(() => { if (sceneApi.r) { sceneApi.r.selectedHw = selectedHw; } }, [selectedHw]);

  // cambios en vivo después de generar
  useEffect(() => {
    if (stage !== 'plant' || !built.current) return;
    sceneApi.r?.setModel(model, 'update');
    const sel = useStore.getState().selectedSector;
    if (sel && !model.sectors.some((s) => s.id === sel)) useStore.getState().selectSector(null);
  }, [model, stage]);

  const generate = () => {
    st.setStage('plant');
    st.setLayer('planta');
    built.current = true;
    st.selectSector(null);
    st.setSummary(false);
    requestAnimationFrame(() => {
      sceneApi.r?.setModel(useStore.getState().active === active ? model : buildPlant(IND, useStore.getState().active, showOptional), 'build');
      setTimeout(() => { if (window.innerWidth >= 860) useStore.getState().setSummary(true); useStore.getState().setLayer('recorrido'); }, 3700);
    });
  };

  return (
    <div className={`app stage-${stage} ${mobile ? 'mobile' : ''}`}>
      <canvas ref={canvasRef} className="scene" />

      {stage === 'intro' && <Intro />}
      {stage === 'preset' && <PresetPicker />}
      {stage === 'config' && (
        <div className="overlay config">
          <div className="config-top"><Logo /><button className="ghost" onClick={() => st.setStage('preset')}>← Cambiar modelo</button></div>
          <div className="config-layout">
            <ConfigPanel model={model} onGenerate={generate} />
            {!mobile && <RoutePreview model={model} />}
          </div>
        </div>
      )}

      {stage === 'plant' && (
        <>
          <TopBar />
          <div className={`left ${mobile ? 'drawer' : ''} ${drawerOpen ? 'open' : ''}`}>
            <ConfigPanel model={model} />
          </div>
          {mobile && drawerOpen && <div className="drawer-back" onClick={() => st.setDrawer(false)} />}
          <Timeline model={model} />
          {selectedSector && <SectorSheet model={model} />}
          {summaryOpen && !selectedSector && <Summary model={model} />}
          {!(mobile && (selectedSector || summaryOpen)) && <div className="zoom">
            <button onClick={() => sceneApi.r?.zoomBy(1.3)} aria-label="Acercar">+</button>
            <button onClick={() => sceneApi.r?.zoomBy(1 / 1.3)} aria-label="Alejar">−</button>
            <button onClick={() => { st.selectSector(null); sceneApi.r?.fitAll(true); }} aria-label="Vista general" title="Volver a planta">⤢</button>
          </div>}
          <BuildToast />
          {selectedHw && <HardwareSheet model={model} />}
          {matrixOpen && <MatrixModal model={model} />}
        </>
      )}
    </div>
  );
}
